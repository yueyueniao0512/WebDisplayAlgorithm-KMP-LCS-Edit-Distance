/* ============================================================
 * algorithms/lcs.js
 * 最长公共子序列（LCS）—— 动态规划 + 回溯
 *
 * 浏览器：<script src="algorithms/lcs.js"> → window.SimAlgo.LCS
 * Node  ：require('./algorithms/lcs.js')   → 模块导出
 *
 * dp[i][j] = A 前 i 个字符与 B 前 j 个字符的 LCS 长度
 *   A[i-1] === B[j-1] → dp[i-1][j-1] + 1
 *   否则              → max(dp[i-1][j], dp[i][j-1])
 * 相似度 = 2 * LCS / (|A| + |B|)
 * ============================================================ */

// ── 用大白话说：这份代码就是「两支笔隔着空儿划连线」 ──────────────
// 和荧光笔不同，中间允许跳过对不上的字；但顺序不能乱，线也不能交叉。
// 靠一张成绩表 dp 来算：dp[i][j] 表示「A 的前 i 个字」和「B 的前 j 个字」
// 最多能对上几个字。填表只有两条规矩：
//   当前两个字一样 → 左上角 +1（连上一条线）；
//   不一样         → 抄上边 / 左边里较大的那个（跳过 A 或跳过 B 的一个字）。
// 表填完，右下角的数字就是最长公共子序列的长度；再从右下角倒着走回去，
// 每走一次「左上对角」就捡回一个公共字，倒过来就是那条连起来的线。
// 相似度 = 2 × 公共字数 ÷ (A 长度 + B 长度)，两段完全一样就是 100 分。

// 【块 1】文件外壳：同一份代码，浏览器和 Node 都能加载
// · 浏览器里挂到 window.SimAlgo，Node 里用 module.exports 导出；
//   所以「页面跑的」和「npm test 测的」是完全相同的实现。
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.SimAlgo = root.SimAlgo || {}; root.SimAlgo.LCS = api; }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // 【块 2】计时器：给卡片上的「耗时 xx ms」用
  // · 有高精度 performance.now 就用它，老环境退回 Date.now。
  var clock = (typeof performance !== 'undefined' && performance.now)
    ? function () { return performance.now(); }
    : function () { return Date.now(); };

  // 【块 3】compute —— 铺表、填表、回溯，一次算出全部证据
  // · 输入：两段字符数组 a、b。
  // · 输出：DP 表、填表顺序、回溯路径、公共子序列、分数、执行日志。
  // · 一句话：先填一张成绩表，再从右下角倒着走回去捡回连上的字。
  function compute(a, b, options) {
    // · 开工：量一下两段各多长，备好日志本
    var opts = options || {};
    var t0 = clock();
    var n = a.length, m = b.length;
    var log = [];

    // 先铺一张 (n+1)×(m+1) 的全 0 表。第 0 行 / 第 0 列表示
    // 「其中一段是空的」—— 一个字也对不上，所以天然是 0。
    var dp = [];
    for (var r = 0; r <= n; r++) dp.push(new Array(m + 1).fill(0));

    // · order 记下填表顺序，页面上的矩阵动画照它一格格亮
    var order = [];
    var equalCells = 0;
    // · 双层循环逐格填表：外行走 A，内行走 B
    for (var i = 0; i <= n; i++) {
      for (var j = 0; j <= m; j++) {
        var isMatch = false;
        if (i > 0 && j > 0) {
          // 两个字一样：连上一条线，在左上角的成绩基础上 +1
          if (a[i - 1] === b[j - 1]) {
            dp[i][j] = dp[i - 1][j - 1] + 1;
            isMatch = true;
            equalCells++;
          } else {
            dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
            // 对不上：只能舍弃 A 的这个字或 B 的这个字，挑更划算的一边
          }
        }
        // · 每填一格记一笔（值 + 是否相等），供页面染色与回放
        order.push({ i: i, j: j, v: dp[i][j], match: isMatch });
      }
    }

    // · 三条日志：表多大、填表规矩、右下角的答案是多少
    log.push({ tag: 'INIT', text: '建立 ' + (n + 1) + ' × ' + (m + 1) + ' 的 DP 矩阵，共 ' + ((n + 1) * (m + 1)) + ' 个单元格，边界初始化为 0。', kind: 'meta' });
    log.push({ tag: 'FILL', text: '按行填表：字符相等取左上角 +1，否则取上 / 左较大值。', kind: '' });
    log.push({ tag: 'FILL', text: '相等字符单元格 ' + equalCells + ' 个；矩阵右下角 dp[' + n + '][' + m + '] = ' + dp[n][m] + '。', kind: 'hit' });

    // 从右下角倒着走回去：哪边的成绩大就往哪边走；
    // 只有走「左上对角」时才算真的连上了一个字（match），把它捡回来。
    // · path 是走过的格子，seq 是捡回来的公共字
    var path = [], seq = [];
    var x = n, y = m;
    // · 从右下角出发，一直走到表格的左上边界
    while (x > 0 && y > 0) {
      // · 分支一：两个字一样 → 走左上对角，把这个字捡回来
      if (a[x - 1] === b[y - 1]) {
        path.push({ i: x, j: y, type: 'match', char: a[x - 1] });
        seq.push(a[x - 1]);
        x--; y--;
      // · 分支二：上边不小于左边 → 往上走（跳过 A 的这个字）
      } else if (dp[x - 1][y] >= dp[x][y - 1]) {
        path.push({ i: x, j: y, type: 'up' });
        x--;
      } else {
        // · 分支三：否则往左走（跳过 B 的这个字）
        path.push({ i: x, j: y, type: 'left' });
        y--;
      }
    }
    // · 走到边界后剩下的行 / 列，只能一路直走把路径补齐
    while (x > 0) { path.push({ i: x, j: y, type: 'up' }); x--; }
    while (y > 0) { path.push({ i: x, j: y, type: 'left' }); y--; }
    // 回溯是从后往前捡字的，倒过来才是正常阅读顺序
    seq.reverse();

    // · 把回溯步数、公共子序列写进日志
    log.push({ tag: 'TRACE', text: '自 dp[' + n + '][' + m + '] 回溯 ' + path.length + ' 步，其中 ' + seq.length + ' 步为对角命中。', kind: 'meta' });
    log.push({ tag: 'LCS', text: '公共子序列「' + (seq.join('') || '（空）') + '」，长度 ' + seq.length + '。', kind: 'ok' });

    // 两段都空算 100 分；否则公共字占两段总字数的比例换算成百分制
    var score = (n + m === 0) ? 100 : (2 * dp[n][m] / (n + m)) * 100;
    // · 换算成百分制分数并记日志
    log.push({
      tag: 'SCORE',
      text: '相似度 = 2 × ' + dp[n][m] + ' / (' + n + ' + ' + m + ') = ' + score.toFixed(2) + ' 分。',
      kind: 'ok'
    });

    // · 交出：分数、整张表、填表顺序、回溯路径、公共字、统计、日志
    return {
      id: 'lcs',
      score: Math.min(100, Math.max(0, score)),
      elapsedMs: clock() - t0,
      // · dp / order / path：矩阵、填表顺序、回溯路径，页面画表就靠这三样
      a: a, b: b, dp: dp, order: order, path: path,
      // · sequence：连出来的公共字；length：它的长度
      sequence: seq, length: dp[n][m],
      // · metrics：格子数、相等格数、回溯步数等统计
      metrics: {
        cells: (n + 1) * (m + 1),
        equalCells: equalCells,
        pathSteps: path.length,
        lcsLength: dp[n][m]
      },
      log: log
    };
  }

  // 【块 4】对外出口：只露 compute 一个函数
  return { compute: compute };
});
