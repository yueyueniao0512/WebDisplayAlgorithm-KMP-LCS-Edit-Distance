/* ============================================================
 * algorithms/similarity.js
 * 编排层：归一化 → 依次真实调用 KMP / LCS / 编辑距离 → 加权综合
 *
 * 浏览器：<script src="algorithms/similarity.js"> → window.SimAlgo.Similarity
 * Node  ：require('./algorithms/similarity.js')   → 模块导出
 *
 * 注意：本文件不含任何算法实现，只负责调度上面三个模块并汇总结果，
 *       保证页面上展示的确实是 algorithms/ 目录里那三份代码在跑。
 * ============================================================ */

// ── 用大白话说：这份代码是「主持人」，自己不做题 ───────────────────
// 它先把两段文字收拾干净（按需忽略大小写 / 空白 / 标点，按 Unicode 字符
// 切开，emoji 不会被劈成两半），再依次请三位检查员各算各的分：
//   荧光笔 KMP 25%  +  连线 LCS 40%  +  红笔编辑距离 35%。
// 最后加权求总分，给一句「高度相似 / 部分相似 / 差异较大」的人话结论。
// 这里没有任何算法实现 —— 页面上跑的确实是 algorithms/ 里那三份代码。

// 【块 1】文件外壳 + 找帮手：同一份代码，浏览器和 Node 都能加载
// · Node 里 require 三个算法文件，浏览器里直接取 window.SimAlgo 上已加载好的；
//   本文件自己不算题，只是把三位检查员请到同一个屋子里。
(function (root, factory) {
  'use strict';
  var deps;
  // · Node 里现场 require 三个算法；浏览器里它们已由前面的 <script> 挂好
  if (typeof module === 'object' && module.exports) {
    deps = {
      KMP: require('./kmp.js'),
      LCS: require('./lcs.js'),
      EditDistance: require('./edit-distance.js')
    };
  } else {
    deps = root.SimAlgo || {};
  }
  var api = factory(deps);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.SimAlgo = root.SimAlgo || {}; root.SimAlgo.Similarity = api; }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (deps) {
  'use strict';

  // · 把三位检查员从依赖包里取出来，下面直接喊名字就行
  var KMP = deps.KMP, LCS = deps.LCS, EditDistance = deps.EditDistance;

  // 收拾文本：按需忽略大小写 / 空白 / 标点，再按 Unicode 字符切开来，
  // 这样 emoji、生僻字都算「一个字」，不会被劈成两半。
  // 【块 2】tokenize —— 把两段文字收拾成「一字一格」的数组
  // · 输入：原始文本 + 归一化开关；输出：字符数组（三种算法都吃这个格式）。
  function tokenize(text, options) {
    // · 读开关：要不要忽略大小写 / 空白 / 标点
    var opts = options || {};
    // · 先把输入稳妥地变成字符串（null 当空串处理）
    var s = String(text == null ? '' : text);
    // · 勾了「忽略大小写」就统一转成小写
    if (opts.ignoreCase) s = s.toLowerCase();
    // · 按 Unicode 码点切开：中文、emoji 都算一个字，不会被劈成两半
    var arr = Array.from(s);
    // · 按开关滤掉空白 / 标点，剩下的才是真正参与比较的字
    if (opts.ignoreSpaces) arr = arr.filter(function (c) { return !/\s/u.test(c); });
    if (opts.ignorePunctuation) arr = arr.filter(function (c) { return !/[\p{P}\p{S}]/u.test(c); });
    // · 交出字符数组，三种算法都吃这个格式
    return arr;
  }

  // 【块 3】analyze —— 请三位检查员各算各的分，再加权给结论
  // · 输入：两段原文 + 配置；输出：三份完整结果、总分、结论、耗时、元信息。
  function analyze(textA, textB, config) {
    // · 读配置：保护上限、归一化开关
    var cfg = config || {};
    var guards = cfg.guards || { maxLength: 600, maxMatrixCells: 360000 };
    var normalize = Object.assign({}, cfg.normalize || {});
    // 两位选手先量个尺寸；太长或矩阵太大就提前拦下，别把浏览器算卡
    var a = tokenize(textA, normalize);
    var b = tokenize(textB, normalize);

    // · 三道体检：太长、矩阵太大、算法没加载 —— 都提前给一句明确错误
    if (a.length > guards.maxLength || b.length > guards.maxLength) {
      return { error: '归一化后单段文本不得超过 ' + guards.maxLength + ' 个字符（当前 A=' + a.length + '，B=' + b.length + '）。' };
    }
    if ((a.length + 1) * (b.length + 1) > guards.maxMatrixCells) {
      return { error: 'DP 矩阵规模超过保护上限 ' + guards.maxMatrixCells + ' 格，请缩短文本。' };
    }
    if (!KMP || !LCS || !EditDistance) {
      return { error: '算法模块未加载：请确认 algorithms/ 下三个 js 文件按 index.html 中的顺序引入。' };
    }

    // · 掐表开始，最后报「耗时 xx ms」
    var t0 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    // 三位检查员依次上场、各自独立算分 —— 页面「同页并行运行」就发生在这三行
    var kmp = KMP.analyze(a, b, cfg);
    var lcs = LCS.compute(a, b, cfg);
    var edit = EditDistance.compute(a, b, cfg);

    // 加权综合：KMP 25% + LCS 40% + 编辑距离 35%（权重在 config/app.config.js）
    var w = cfg.weights || { kmp: 0.25, lcs: 0.40, edit: 0.35 };
    var combined = w.kmp * kmp.score + w.lcs * lcs.score + w.edit * edit.score;
    // · 阈值决定这句结论怎么下（≥75 高度相似 / ≥45 部分相似 / 否则差异较大）
    var th = cfg.thresholds || { high: 75, medium: 45 };
    // 按阈值把分数翻成一句人话结论
    var verdict = combined >= th.high ? '高度相似'
                : combined >= th.medium ? '部分相似'
                : '差异较大';
    // · 掐表结束
    var t1 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();

    // · 交出：原文、归一化后的字符、三份完整结果、权重、总分、结论、耗时
    return {
      originalA: String(textA == null ? '' : textA),
      originalB: String(textB == null ? '' : textB),
      a: a, b: b,
      normalize: normalize,
      // · results：三位检查员的完整结果，§ 02 三张卡片各取一份
      results: { kmp: kmp, lcs: lcs, edit: edit },
      weights: w,
      thresholds: th,
      // · combined / verdict：加权总分（夹在 0~100）与一句人话结论
      combined: Math.min(100, Math.max(0, combined)),
      verdict: verdict,
      elapsedMs: t1 - t0,
      // · meta：归一化前后的长度，页面「xx 字符」用它
      meta: {
        lenA: a.length, lenB: b.length,
        rawA: Array.from(String(textA == null ? '' : textA)).length,
        rawB: Array.from(String(textB == null ? '' : textB)).length
      }
    };
  }

  // 【块 4】对外出口：只露 tokenize 和 analyze
  return { tokenize: tokenize, analyze: analyze };
});
