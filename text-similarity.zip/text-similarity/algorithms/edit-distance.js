/* ============================================================
 * algorithms/edit-distance.js
 * 编辑距离（Levenshtein Distance）—— 动态规划 + 最小操作回溯
 *
 * 浏览器：<script src="algorithms/edit-distance.js"> → window.SimAlgo.EditDistance
 * Node  ：require('./algorithms/edit-distance.js')   → 模块导出
 *
 * dp[i][j] = 把 A 前 i 个字符改成 B 前 j 个字符的最小代价
 *   dp[i][0] = i，dp[0][j] = j
 *   dp[i][j] = min( 删除 dp[i-1][j]+1, 插入 dp[i][j-1]+1,
 *                   保留/替换 dp[i-1][j-1] + (A[i-1]===B[j-1] ? 0 : 1) )
 * 相似度 = (1 - 距离 / max(|A|,|B|)) × 100
 * ============================================================ */

// ── 用大白话说：这份代码就是「拿红笔改作文，数最少改几处」 ─────────
// 改一个字、加一个字、删一个字，各算 1 笔；原字能留就留，不花钱。
// 同样画一张表：dp[i][j] = 把 A 前 i 个字改成 B 前 j 个字最少要落几笔。
// 第一行 / 第一列是「从空串一路加字」或「一路删到空」，所以是 0,1,2,3…
// 中间每一格都有三种选择，挑最省笔的那种：
//   删掉 A 的这个字 / 插进 B 的这个字 / 对上或替换这个字（一样 0 笔，不一样 1 笔）
// 填完表，右下角就是最少笔数。再从右下角倒着走回去，把当时挑的每一步
// 记下来，就得到「保留 / 替换 / 插入 / 删除」这份批改清单（页面上的 diff）。
// 相似度 = (1 − 最少笔数 ÷ 较长文本长度) × 100，一笔都不用改就是 100 分。

// 【块 1】文件外壳：同一份代码，浏览器和 Node 都能加载
// · 浏览器里挂到 window.SimAlgo，Node 里用 module.exports 导出；
//   所以「页面跑的」和「npm test 测的」是完全相同的实现。
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.SimAlgo = root.SimAlgo || {}; root.SimAlgo.EditDistance = api; }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // 【块 2】计时器：给卡片上的「耗时 xx ms」用
  // · 有高精度 performance.now 就用它，老环境退回 Date.now。
  var clock = (typeof performance !== 'undefined' && performance.now)
    ? function () { return performance.now(); }
    : function () { return Date.now(); };

  // 【块 3】compute —— 代价表 + 回溯出「批改清单」
  // · 输入：两段字符数组 a、b。
  // · 输出：代价表、回溯路径、保留/替换/插入/删除清单、对齐结果、分数、日志。
  // · 一句话：先算出最少要改几笔，再倒着把当时挑的每一步记下来。
  function compute(a, b, options) {
    // · 开工：量一下两段各多长，备好日志本
    var opts = options || {};
    var t0 = clock();
    var n = a.length, m = b.length;
    var log = [];

    // · 先铺一张全 0 的代价表
    var dp = [];
    for (var r = 0; r <= n; r++) dp.push(new Array(m + 1).fill(0));
    // 首列 / 首行：把 A 一路删空、或从空串一路加出 B，
    // 分别要 i 笔、j 笔，所以直接填 0,1,2,3…
    for (var i0 = 0; i0 <= n; i0++) dp[i0][0] = i0;
    for (var j0 = 0; j0 <= m; j0++) dp[0][j0] = j0;

    // · order 记填表顺序，页面矩阵动画按它一格格亮
    var order = [];
    // · 双层循环逐格算「最少要落几笔」
    for (var i = 0; i <= n; i++) {
      for (var j = 0; j <= m; j++) {
        if (i > 0 && j > 0) {
          // 两个字一样就白留（0 笔），不一样替换要花 1 笔
          var cost = a[i - 1] === b[j - 1] ? 0 : 1;
          // 删 / 插 / 保留或替换，三条路里挑最省笔的一条填进这一格
          dp[i][j] = Math.min(
            dp[i - 1][j] + 1,          // 删除
            dp[i][j - 1] + 1,          // 插入
            dp[i - 1][j - 1] + cost    // 保留 / 替换
          );
        }
        // · 每格记一笔，供页面染色与回放
        order.push({ i: i, j: j, v: dp[i][j], match: i > 0 && j > 0 && a[i - 1] === b[j - 1] });
      }
    }

    // · 三条日志：表多大、填表规矩、右下角的最少笔数
    log.push({ tag: 'INIT', text: '建立 ' + (n + 1) + ' × ' + (m + 1) + ' 代价矩阵；首行 / 首列初始化为 0…' + n + ' 与 0…' + m + '。', kind: 'meta' });
    log.push({ tag: 'FILL', text: '每格取「删除 / 插入 / 替换」三者最小值；字符相等时代价为 0。', kind: '' });
    log.push({ tag: 'FILL', text: '最小编辑代价 dp[' + n + '][' + m + '] = ' + dp[n][m] + '。', kind: 'hit' });

    // 从右下角倒着走：看当时是走「左上对角 / 上 / 左」哪条最划算，
    // 反推出那一笔是「保留或替换 / 删除 / 插入」，一步步记成批改清单。
    // · opsRev 是倒着记的批改清单，path 是走过的格子
    var opsRev = [], path = [];
    var x = n, y = m;
    // · 从右下角倒着走，直到回到左上角
    while (x > 0 || y > 0) {
      path.push({ i: x, j: y });
      if (x > 0 && y > 0) {
        // · 先算三条路各要几笔：对角（留或换）、上（删）、左（插）
        var cost2 = a[x - 1] === b[y - 1] ? 0 : 1;
        var diag = dp[x - 1][y - 1] + cost2;
        var up = dp[x - 1][y] + 1;
        var left = dp[x][y - 1] + 1;
        // diag=保留或替换，up=删 A 的字，left=插 B 的字；谁最小就选谁
        var best = Math.min(diag, up, left);
        // · 对角最省 → 这个字保留（一样）或替换（不一样）
        if (best === diag) {
          opsRev.push({ type: cost2 === 0 ? '保留' : '替换', a: a[x - 1], b: b[y - 1], cost: cost2 });
          x--; y--;
          continue;
        }
        // · 往上最省 → 删掉 A 的这个字；两条都不选就是往左插入 B 的字
        if (best === up) {
          opsRev.push({ type: '删除', a: a[x - 1], b: null, cost: 1 });
          x--;
          continue;
        }
        opsRev.push({ type: '插入', a: null, b: b[y - 1], cost: 1 });
        y--;
        continue;
      }
      // · 走到边界：只剩 A 就一路删，只剩 B 就一路插
      if (x > 0) {
        opsRev.push({ type: '删除', a: a[x - 1], b: null, cost: 1 });
        x--;
      } else {
        opsRev.push({ type: '插入', a: null, b: b[y - 1], cost: 1 });
        y--;
      }
    }

    // 回溯是倒着记的，翻过来才是从 A 改到 B 的正常批改顺序
    // · counts 数一数四种操作各几笔；alignment 翻成页面 diff 用的英文标记
    var ops = opsRev.reverse();
    var counts = { 保留: 0, 替换: 0, 插入: 0, 删除: 0 };
    ops.forEach(function (op) { counts[op.type]++; });
    var alignment = ops.map(function (op) {
      return {
        type: { '保留': 'match', '替换': 'sub', '插入': 'ins', '删除': 'del' }[op.type],
        a: op.a, b: op.b, cost: op.cost
      };
    });

    // · 把回溯步数、批改清单写进日志
    log.push({ tag: 'TRACE', text: '回溯 ' + path.length + ' 格，得到 ' + ops.length + ' 步操作（保留 ' + counts['保留'] + ' / 替换 ' + counts['替换'] + ' / 插入 ' + counts['插入'] + ' / 删除 ' + counts['删除'] + '）。', kind: 'meta' });
    log.push({ tag: 'OPS', text: '编辑脚本：' + (ops.slice(0, 18).map(function (o) {
      return o.type + (o.type === '插入' ? '[' + o.b + ']' : '[' + o.a + (o.type === '替换' ? '→' + o.b : '') + ']');
    }).join(' ') || '（无）') + (ops.length > 18 ? ' …' : ''), kind: 'hit' });

    // 一笔都不用改 = 100 分；改得越多、文本越短，扣得越狠
    var denom = Math.max(n, m, 1);
    var score = (1 - dp[n][m] / denom) * 100;
    // · 换算成百分制分数并记日志
    log.push({
      tag: 'SCORE',
      text: '相似度 = (1 − ' + dp[n][m] + ' / ' + denom + ') × 100 = ' + Math.max(0, score).toFixed(2) + ' 分。',
      kind: 'ok'
    });

    // · 交出：分数、代价表、回溯路径、批改清单、对齐结果、统计、日志
    return {
      id: 'edit',
      score: Math.min(100, Math.max(0, score)),
      elapsedMs: clock() - t0,
      // · dp / order / path：代价表、填表顺序、回溯路径
      a: a, b: b, dp: dp, order: order, path: path,
      // · ops / alignment：批改清单，以及页面 diff 用的对齐结果
      ops: ops, alignment: alignment, distance: dp[n][m], counts: counts,
      // · metrics：四类操作各落了几笔，供统计格子显示
      metrics: {
        cells: (n + 1) * (m + 1),
        distance: dp[n][m],
        substitutions: counts['替换'],
        insertions: counts['插入'],
        deletions: counts['删除'],
        keeps: counts['保留']
      },
      log: log
    };
  }

  // 【块 4】对外出口：只露 compute 一个函数
  return { compute: compute };
});
