/* ============================================================
 * algorithms/kmp.js
 * KMP（Knuth–Morris–Pratt）字符串匹配 —— 页面实际加载并执行的算法代码
 *
 * 本文件同时支持：
 *   浏览器：<script src="algorithms/kmp.js">  →  window.SimAlgo.KMP
 *   Node  ：require('./algorithms/kmp.js')    →  模块导出（供 tests 使用）
 *
 * 相似度思路：KMP 本身是「精确匹配」算法，这里用它作为子串搜索引擎，
 *   1) 二分长度 + KMP 判定，求最长公共子串 / 公共片段；
 *   2) 贪心地把文本 A 切分成若干在文本 B 中真实出现的公共片段；
 *   3) 公共片段覆盖率 = 命中字符数 / max(|A|,|B|)，作为 KMP 视角的相似度。
 * 所有 search 都走本文件实现的 next 前缀表，不使用 indexOf / includes。
 * ============================================================ */

// ── 用大白话说：这份代码就是那支「荧光笔」 ────────────────────────
// 它只划「连成一整块、一字不差」的相同文字，散在各处的同字不算数。
// 三个动作（对应下面的块 3 ～ 块 6）：
//   ① 先给要找的那句话做一张「退路表」next。比对到一半对不上时，
//      查表就知道该把模式串滑回哪儿，文本不用往回退。
//   ② 拿着表在另一段文字里逐字往前走，边走边记轨迹，
//      页面上那排跳动的指针，就是照着这份记录一帧帧重放的。
//   ③ 「最长的一块到底有多长」不挨个试，改成二分猜长度：
//      猜 L → 把 A 里所有长 L 的片段丢去 B 里验证 → 命中就猜更长，
//      没命中就猜更短。找到一块划掉，左右两半接着找。
// 最后：划中的字数 ÷ 较长那段的总字数 = KMP 这一路给出的相似度分。
// 读法：陶土色【块 N】标题 = 这一块在干什么；「// · 」开头的是段内说明。
// 下面每行都是页面真正跑的代码，注释只是配给它的「说明书」。

// 【块 1】文件外壳：同一份代码，浏览器和 Node 都能加载
// · 浏览器里挂到 window.SimAlgo，Node 里用 module.exports 导出；
//   所以「页面跑的」和「npm test 测的」是完全相同的实现。
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.SimAlgo = root.SimAlgo || {}; root.SimAlgo.KMP = api; }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // 【块 2】计时器：给卡片上的「耗时 xx ms」用
  // · 有高精度 performance.now 就用它，老环境退回 Date.now。
  var clock = (typeof performance !== 'undefined' && performance.now)
    ? function () { return performance.now(); }
    : function () { return Date.now(); };

  // 【块 3】做「退路表」next —— 比对断了往哪儿退
  // · 输入：要找的那句话 pattern；输出：next 表 + trace（每次回退的录像）。
  // · 白话：记下「一句话的开头和结尾重复了多长」，下次比对到一半对不上，
  //   就能直接滑回那个位置，不必从头再来；trace 供页面画回退指针。
  function buildNext(pattern) {
    // · 准备三样东西：next 表（每位一个坑）、trace（回退录像）、j（已匹配长度）
    var next = new Array(pattern.length).fill(0);
    var trace = [];
    var j = 0;
    // · 从第 2 个字起逐位往后看，拿 pattern[i] 和 pattern[j] 比
    for (var i = 1; i < pattern.length; i++) {
      // · 对不上就沿退路表往回跳，直到能对上或退回开头；每跳一次都录下来
      while (j > 0 && pattern[i] !== pattern[j]) {
        trace.push({ i: i, j: j, action: 'fallback', from: j, to: next[j - 1], char: pattern[i] });
        j = next[j - 1];
      }
      // · 对上了，已匹配长度 +1
      if (pattern[i] === pattern[j]) j++;
      next[i] = j;
      // 这个位置能复用多长的前后缀，记进表里
      trace.push({ i: i, j: j, action: 'set', value: j, char: pattern[i] });
    }
    // · 交出两张表：一张给程序查退路，一张给页面画回退动画
    return { next: next, trace: trace };
  }

  // 【块 4】逐字比对 search —— 拿着退路表在文本里往前滑
  // · 输入：text（被搜的全文）、pattern（要找的话）。
  // · 输出：命中位置 matches、逐帧轨迹 steps、比较与回退次数。
  // · 关键规矩：文本指针 i 只进不退；失配只把 j 按 next 滑回去，这就是 KMP 快的原因。
  function search(text, pattern, options) {
    // · 先收参数：要不要录轨迹、最多录多少帧
    var opts = options || {};
    var capture = opts.captureSteps !== false;
    var maxSteps = opts.maxSteps || 3000;
    // · 要找的是空串，没什么可比，直接交白卷
    if (!pattern.length) {
      return { matches: [], steps: [], next: [], comparisons: 0, fallbacks: 0, truncated: false };
    }

    // · 开工前把退路表做好，后面失配全靠它
    var next = buildNext(pattern).next;
    // · matches 记命中位置，steps 记每一帧，三个计数器给页面报数
    var matches = [], steps = [];
    var comparisons = 0, fallbacks = 0, truncated = false;
    var i = 0, j = 0;

    // · 主循环：文本指针 i 只进不退，这是 KMP 省时间的关键
    while (i < text.length) {
      comparisons++;
      var pj = pattern[j];

      // · 分支一：这两个字对上了，两个指针一起往前
      if (text[i] === pj) {
        if (capture && steps.length < maxSteps) {
          steps.push({ i: i, j: j, action: 'match', textChar: text[i], patternChar: pj });
        }
        i++; j++;
        // · 一整句都撞上了 → 记下起点，再按退路表继续找下一处
        if (j === pattern.length) {
          var start = i - j;
          matches.push(start);
          if (capture && steps.length < maxSteps) {
            steps.push({ i: i, j: j, action: 'found', start: start });
          }
          j = next[j - 1];
          // 命中一整块后也不必从头再来，按退路表继续找下一处
        }
      // · 分支二：对不上但已匹配了一截 → 查表回退，i 原地不动
      } else if (j > 0) {
        var from = j;
        j = next[j - 1];
        fallbacks++;
        if (capture && steps.length < maxSteps) {
          steps.push({ i: i, j: j, action: 'fallback', from: from, to: j,
                       textChar: text[i], patternChar: pattern[from] });
        }
      } else {
        // · 分支三：第一个字就对不上 → 文本指针往前挪一格
        if (capture && steps.length < maxSteps) {
          steps.push({ i: i, j: j, action: 'skip', textChar: text[i], patternChar: pj });
        }
        i++;
      }
      // · 轨迹太长就打住，别把浏览器内存撑爆
      if (capture && steps.length >= maxSteps) truncated = true;
    }

    // · 把命中位置、逐帧录像、统计数字一起交回页面
    return {
      matches: matches, steps: steps, next: next,
      comparisons: comparisons, fallbacks: fallbacks, truncated: truncated
    };
  }

  // 【块 5】二分猜「最长的一模一样的整块」有多长
  // · 不挨个长度试：猜 L → 把 A 里所有长 L 的片段丢去 B 里验证 →
  //   命中就猜更长、没命中就猜更短，几轮就能逼近答案。
  // · seen 跳过重复片段，budget 是超长文本时防止浏览器算到卡住的保护。
  function longestCommonSubstring(a, b, options) {
    // · 读出预算上限：候选数、总比较次数、最短块长度
    var opts = options || {};
    var budget = opts.budget || { comparisons: 0 };
    var maxCandidates = opts.maxCandidates || 500;      // 每轮候选上限
    var maxComparisons = opts.maxComparisons || Infinity; // 全局比较预算
    var minLength = opts.minLength || 1;
    var rounds = [];
    var tried = 0, used = 0, budgetHit = false;
    var best = { substring: [], length: 0, posA: -1, posB: -1 };

    // · 有一段是空的，最长公共块自然是 0，直接返回空答案
    if (!a.length || !b.length) {
      return {
        substring: [], length: 0, posA: -1, posB: -1,
        rounds: rounds, candidatesTried: 0, comparisons: 0, budgetHit: false
      };
    }

    // · 二分范围：最短从 minLength 起，最长不会超过较短的那段
    var lo = minLength, hi = Math.min(a.length, b.length);
    while (lo <= hi) {
      // 这一轮先猜「整块长度 = L」；命中就往更长的方向继续猜
      var L = Math.floor((lo + hi) / 2);
      // · seen 记这一轮试过的片段，重复的不再白比一遍
      var seen = new Set();
      var found = null;

      // · 把 A 里所有长 L 的片段挨个拿去 B 里验证
      for (var s = 0; s + L <= a.length; s++) {
        if (seen.size >= maxCandidates || budget.comparisons >= maxComparisons) {
          budgetHit = true; break;
        }
        // · 切出候选片段，拼成字符串当「去重钥匙」
        var sub = a.slice(s, s + L);
        var key = sub.join('\u0001');
        if (seen.has(key)) continue;
        seen.add(key);
        tried++;
        // · 用块 4 的 search 去 B 里找它；这里不录轨迹，只要有没有命中
        var res = search(b, sub, { captureSteps: false });
        used += res.comparisons;
        budget.comparisons += res.comparisons;
        // · 只要有一个命中，这个长度就成立，不必再试后面的片段
        if (res.matches.length) {
          found = { s: s, posB: res.matches[0], sub: sub };
          break;
        }
      }

      // · 这一轮猜的结果记下来，页面「二分过程」日志用它
      rounds.push({ length: L, hit: !!found, candidates: seen.size });
      // · 命中 → 把下界抬到 L+1，继续赌更长的
      if (found) {
        best = { substring: found.sub, length: L, posA: found.s, posB: found.posB };
        lo = L + 1;
      } else {
        // · 没命中 → 上界压到 L-1；预算用尽就直接收工
        hi = L - 1;
        if (budgetHit) break;
      }
    }

    // · 交出最长那块的文字、长度、在 A / B 里的位置，以及各轮记录
    return {
      substring: best.substring, length: best.length, posA: best.posA, posB: best.posB,
      rounds: rounds, candidatesTried: tried, comparisons: used, budgetHit: budgetHit
    };
  }

  // 【块 6】荧光笔开工 coverage —— 把 A 切成一块块公共片段
  // · 每次在当前区间找最长的一块划掉，左右两半重新排队继续找（像切蛋糕）；
  //   最后 划中字数 ÷ 较长文本长度 = 这一路的覆盖率得分。
  function coverage(a, b, options) {
    var opts = options || {};
    var minBlock = opts.minBlockLength || 2;
    var maxBlocks = opts.maxBlocks || 22;
    var budget = opts.budget || { comparisons: 0 };
    var subOpts = {
      budget: budget,
      maxCandidates: opts.maxCandidates || 500,
      maxComparisons: opts.maxComparisons || Infinity,
      minLength: minBlock
    };

    // · blocks 是划出来的整块清单；queue 是「还没找过的区间」
    var blocks = [];
    var queue = [{ start: 0, end: a.length }];
    var comparisons = 0, candidates = 0, rounds = 0;
    var budgetHit = false;

    // · 只要还有区间、且没划够上限，就一直找下去
    while (queue.length && blocks.length < maxBlocks) {
      // · 取出一个区间；太短（比最短块还短）就跳过
      var seg = queue.shift();
      if (seg.end - seg.start < minBlock) continue;

      // · 在这个区间里找最长的一块，顺手累计比较次数
      var res = longestCommonSubstring(a.slice(seg.start, seg.end), b, subOpts);
      comparisons += res.comparisons;
      candidates += res.candidatesTried;
      rounds += res.rounds.length;
      if (res.budgetHit) { budgetHit = true; break; }
      if (res.length < minBlock) continue;

      // · 把区间内的相对位置换回全文的绝对位置
      var absStart = seg.start + res.posA;
      // · 记下这一块的文字、在 A / B 里的起点、长度
      blocks.push({
        text: res.substring.join(''),
        startA: absStart,
        startB: res.posB,
        length: res.length
      });
      // · 划掉中间，左右两半重新排队，等下一轮继续划
      queue.push({ start: seg.start, end: absStart });
      queue.push({ start: absStart + res.length, end: seg.end });
    }

    var matched = blocks.reduce(function (sum, x) { return sum + x.length; }, 0);
    // 荧光笔一共划中了多少字
    // · 分母取较长那段（全 0 时保底 1），免得除以 0
    var denom = Math.max(a.length, b.length) || 1;
    // · 交出：划了哪些块、划中多少字、覆盖率得分、统计数字
    return {
      blocks: blocks, matched: matched, denom: denom,
      score: Math.min(100, Math.max(0, matched / denom * 100)),
      comparisons: comparisons, candidates: candidates, rounds: rounds,
      budgetHit: budgetHit
    };
  }

  // 【块 7】总入口 analyze —— 跑一遍，把「看得见的证据」全打包
  // · 分数只有一个，但页面要画表、放动画、打日志，所以 next 表、指针轨迹、
  //   公共块、二分过程、统计数字都得一起交出去，才能一帧帧回放。
  function analyze(a, b, config) {
    // · 收配置：计算保护上限、演示要展示哪些片段
    var cfg = config || {};
    var guards = cfg.guards || {};
    var t0 = clock();
    var log = [];

    // · 全篇共用一份「比较次数预算」，防止长文本把页面算卡
    var sharedBudget = { comparisons: 0 };
    var common = {
      budget: sharedBudget,
      maxCandidates: guards.maxKmpCandidates || 500,
      maxComparisons: guards.maxKmpComparisons || Infinity
    };

    // · 下面每一步都往 log 写一句人话，页面「执行日志」逐条播出来
    log.push({ tag: 'INIT', text: '输入长度 |A|=' + a.length + '，|B|=' + b.length + '；字符按 Unicode 码点切分。', kind: 'meta' });

    // · 先请荧光笔把 A 划一遍（这一路的分数就是最终分数来源）
    var cov = coverage(a, b, Object.assign({}, common, {
      minBlockLength: guards.minBlockLength || 2,
      maxBlocks: guards.maxBlocks || 22
    }));

    // · 再单独求一次「最长公共整块」，用来挑演示样本
    var global = longestCommonSubstring(a, b, common);
    // · 演示用哪句话？优先挑最长的公共块；没有就退而取 A 开头几个字
    var demoPattern = global.length
      ? global.substring
      : (a.length ? a.slice(0, Math.min(6, a.length)) : b.slice(0, Math.min(6, b.length)));
    if (!demoPattern.length) demoPattern = ['·'];
    // · 演示文本只截前 48 字，太长页面画不下
    var demoText = (b.length ? b : a).slice(0, 48);

    // · 为演示样本现做一张 next 表，卡片「A · next 前缀表」画的就是它
    var built = buildNext(demoPattern);
    log.push({ tag: 'NEXT', text: '构造前缀表 next=[' + built.next.join(',') + ']（模式串长度 ' + demoPattern.length + '）。', kind: 'meta' });

    // · 把二分过程的前几轮写进日志
    global.rounds.slice(0, 7).forEach(function (r) {
      log.push({
        tag: 'BINARY',
        text: '二分候选长度 L=' + r.length + '，KMP 验证 ' + r.candidates + ' 个候选 → ' + (r.hit ? '命中，继续放大' : '未命中，缩小上界'),
        kind: r.hit ? 'hit' : ''
      });
    });

    log.push({ tag: 'LONGEST', text: '最长公共子串长度 ' + global.length + '（A@' + global.posA + ' ↔ B@' + global.posB + '）。', kind: 'ok' });
    // · 把划出来的公共块也写进日志（最多 12 条，多了就汇总一句）
    cov.blocks.slice(0, 12).forEach(function (blk, k) {
      log.push({ tag: 'BLOCK ' + (k + 1), text: '公共片段「' + blk.text + '」 A@' + blk.startA + ' ↔ B@' + blk.startB + '，长度 ' + blk.length, kind: 'hit' });
    });
    if (cov.blocks.length > 12) {
      log.push({ tag: 'BLOCK', text: '… 其余 ' + (cov.blocks.length - 12) + ' 个片段已计入覆盖率。', kind: '' });
    }

    // · 跑一遍完整 KMP 匹配，录下逐帧轨迹给「B · 匹配指针轨迹」回放
    var demo = search(demoText, demoPattern, { maxSteps: 600 });
    log.push({
      tag: 'TRACE',
      text: 'KMP 轨迹回放：' + demo.comparisons + ' 次字符比较、' + demo.fallbacks + ' 次 next 回退、命中 ' + demo.matches.length + ' 处。',
      kind: 'meta'
    });
    log.push({
      tag: 'SCORE',
      text: '覆盖率 = ' + cov.matched + ' / ' + cov.denom + ' = ' + cov.score.toFixed(2) + ' 分。',
      kind: 'ok'
    });
    // · 若触发了预算保护，坦白告诉用户结果是近似值
    if (cov.budgetHit || global.budgetHit) {
      log.push({ tag: 'GUARD', text: '触发计算预算保护，结果为受限近似值（可缩短文本获得精确解）。', kind: '' });
    }

    // · 最后打包：分数 + 三张可视化要用的数据 + 统计 + 日志，一次交给页面
    return {
      id: 'kmp',
      score: cov.score,
      elapsedMs: clock() - t0,
      // · coverage / longest / blocks：荧光笔划出来的三份证据
      coverage: cov,
      longest: global,
      blocks: cov.blocks,
      // · pattern / text / next / nextTrace / steps / matches：演示区重放素材
      pattern: demoPattern,
      text: demoText,
      next: built.next,
      nextTrace: built.trace,
      steps: demo.steps,
      matches: demo.matches,
      // · metrics：卡片底部那些统计格子的数字
      metrics: {
        // · 下面这些数字直接喂给卡片底部的统计格子
        matched: cov.matched,
        denom: cov.denom,
        blocks: cov.blocks.length,
        longestLength: global.length,
        candidates: cov.candidates + global.candidatesTried,
        totalComparisons: sharedBudget.comparisons,
        demoComparisons: demo.comparisons,
        fallbacks: demo.fallbacks,
        rounds: cov.rounds + global.rounds.length
      },
      log: log
    };
  }

  // 【块 8】对外出口：只露这五个函数给页面和测试调用
  return {
    buildNext: buildNext,
    search: search,
    longestCommonSubstring: longestCommonSubstring,
    coverage: coverage,
    analyze: analyze
  };
});
