/* ============================================================
 * config/app.config.js
 * 浏览器运行时配置（同时以 UMD 形式供 Node 测试脚本 require）
 * 这是页面实际读取的配置，不是示例文件。
 * ============================================================ */
(function (root, factory) {
  'use strict';
  var cfg = factory();
  if (typeof module === 'object' && module.exports) module.exports = cfg;
  else root.APP_CONFIG = cfg;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  return {
    app: {
      name: '文本相似度检测',
      edition: 'ALGORITHM NOTEBOOK / 01',
      version: '1.0.0',
      styleTemplate: 'opus5.5'
    },

    /* 归一化选项的默认值 */
    normalize: {
      ignoreCase: false,
      ignoreSpaces: false,
      ignorePunctuation: false
    },

    /* 综合评分权重，三者之和必须为 1 */
    weights: {
      kmp: 0.25,
      lcs: 0.40,
      edit: 0.35
    },

    /* 相似度判定阈值（百分制） */
    thresholds: {
      high: 75,
      medium: 45
    },

    /* 轨迹回放动画 */
    animation: {
      enabled: true,
      stepDelayMs: 12,
      maxCellsPerFrame: 3,
      maxRenderCells: 2500,
      maxRenderSide: 44,
      maxLogLines: 200
    },

    /* 直观演示动画（荧光笔 / 划连线 / 红笔批改） */
    analogy: {
      enabled: true,
      maxChars: 28,        // 演示区显示的字符数上限，超出会提示（评分仍按全文）
      frames: 70,          // 单次动画最大帧数
      speedFactor: 1.6,    // 相对轨迹回放的放慢倍数，便于看清笔触
      loop: true,          // 检测完成后自动反复重播三段演示
      loopDelayMs: 1600,   // 每遍演完后的停顿（毫秒）
      pauseWhenHidden: true // 页面切到后台时暂停空转，回到前台继续
    },

    /* § 01 以上首屏文字：打开淡入 + 滚动淡出/淡入 */
    heroFade: {
      enabled: true,          // 关闭后首屏文字始终完全可见（也可临时用 ?fade=0）
      introMs: 1150,          // 打开时入场时长（含一次轻微淡出回摆）
      introDip: 0.55,         // 入场中途淡出到多淡；设为 1 则打开时只有淡入、不淡出
      fadeDistance: 0,        // 完全淡出所需滚动距离(px)；0 = 自动取到 § 01 顶部
      maxFadeDistance: 520,   // 自动距离的上限
      minOpacity: 0,          // 完全淡出后的不透明度（0 = 全隐；0.12 可留一点余韵）
      respectReducedMotion: true
    },

    /* 输入与计算保护 */
    guards: {
      maxLength: 600,
      maxMatrixCells: 360000,
      maxKmpCandidates: 500,
      maxKmpComparisons: 4000000,
      maxBlocks: 22,
      minBlockLength: 2
    },

    /* 算法元信息（页面卡片与日志使用） */
    algorithms: [
      {
        id: 'kmp',
        index: '01',
        name: 'KMP 字符串匹配',
        en: 'KNUTH–MORRIS–PRATT',
        complexity: 'O(n + m)',
        idea: '用 next 前缀表跳过无效回溯，把公共片段搜索变成线性匹配；以「公共片段覆盖率」衡量相似。'
      },
      {
        id: 'lcs',
        index: '02',
        name: '最长公共子序列',
        en: 'LONGEST COMMON SUBSEQUENCE',
        complexity: 'O(n · m)',
        idea: '动态规划填表并回溯，找出两段文本保持顺序的最长公共字符序列。'
      },
      {
        id: 'edit',
        index: '03',
        name: '编辑距离',
        en: 'LEVENSHTEIN DISTANCE',
        complexity: 'O(n · m)',
        idea: '动态规划求把文本 A 改成文本 B 所需的最少插入、删除、替换次数。'
      }
    ],

    /* 示例文本 */
    samples: [
      {
        id: 'near',
        label: '近似中文',
        a: '文本相似度检测用于判断两段文字的相似程度',
        b: '文本相似度检测用来判断两段文字的相似程度'
      },
      {
        id: 'same',
        label: '完全相同',
        a: '知识就是力量，实践是检验真理的唯一标准。',
        b: '知识就是力量，实践是检验真理的唯一标准。'
      },
      {
        id: 'diff',
        label: '差异较大',
        a: '春天来了，花园里的玫瑰依次盛开。',
        b: '服务器在凌晨三点完成了全量数据备份。'
      },
      {
        id: 'en',
        label: '英文近似',
        a: 'the quick brown fox jumps over the lazy dog',
        b: 'the quick brown fox jumps over a lazy dog'
      }
    ],

    /* 「查看本页实际运行的源码」面板读取的真实文件路径 */
    sources: {
      kmp: 'algorithms/kmp.js',
      lcs: 'algorithms/lcs.js',
      edit: 'algorithms/edit-distance.js',
      similarity: 'algorithms/similarity.js'
    }
  };
});
