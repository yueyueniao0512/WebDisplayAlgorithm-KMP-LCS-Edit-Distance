/* ============================================================
 * hero-fade.js
 * 只做一件事：把滚动进度换算成 --hero-fade，写到 <html> 上。
 * 打开时的淡入（含一次淡出回摆）由 hero-fade.css 纯 CSS 完成，
 * 这样脚本失败或尚未执行时也不会出现「先隐藏后闪现」。
 *
 * 不拦截、不改写滚动；passive 监听 + rAF 节流，与 scroll-anchor.js 并存。
 * 配置：config/app.config.js 的 heroFade 段；?fade=0 可临时关闭。
 * ============================================================ */
(function () {
  'use strict';

  var root = document.documentElement;
  var CFG = (window.APP_CONFIG && window.APP_CONFIG.heroFade) || {};
  var params = new URLSearchParams(window.location.search);

  function turnOff(reason) {
    root.classList.add('no-hero-fade');
    window.HeroFade = { enabled: false, reason: reason, opacity: 1, range: 0 };
  }

  if (CFG.enabled === false) return turnOff('config');
  if (params.get('fade') === '0') return turnOff('query');
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduced && CFG.respectReducedMotion !== false) return turnOff('reduced-motion');

  /* 让配置真正驱动 CSS（不写则用样式表里的回退值） */
  if (CFG.introMs) root.style.setProperty('--hero-intro-ms', Number(CFG.introMs) + 'ms');
  if (CFG.introDip != null) root.style.setProperty('--hero-intro-dip', String(Number(CFG.introDip)));

  var io = document.querySelector('.io');
  var minOpacity = Math.max(0, Math.min(1, CFG.minOpacity == null ? 0 : Number(CFG.minOpacity)));
  var range = 420;

  function measure() {
    var auto = io ? io.offsetTop : 420;                 /* 滚到 § 01 出现时头部正好淡完 */
    var cap = Number(CFG.maxFadeDistance) || 520;       /* 防止首屏很高时淡出过程被拉太长 */
    var fixed = Number(CFG.fadeDistance) || 0;
    range = Math.max(160, fixed || Math.min(auto, cap));
  }

  var ticking = false;

  function apply() {
    ticking = false;
    var y = window.pageYOffset || root.scrollTop || 0;
    var t = Math.min(1, Math.max(0, y / range));
    var eased = t * t * (3 - 2 * t);                    /* smoothstep：起止两端更柔和 */
    var v = 1 - (1 - minOpacity) * eased;
    root.style.setProperty('--hero-fade', v.toFixed(3));
  }

  function schedule() {
    if (ticking) return;
    ticking = true;
    window.requestAnimationFrame(apply);
    /* 兜底：rAF 被挂起时（后台标签页、低帧率、无头虚拟时间）ticking 会永久卡住，
       导致此后所有滚动都不再更新。补一次定时落地，让调度能自愈。 */
    window.setTimeout(function () { if (ticking) apply(); }, 70);
  }

  window.addEventListener('scroll', schedule, { passive: true });
  window.addEventListener('resize', function () { measure(); schedule(); }, { passive: true });

  measure();
  apply();   /* 刷新后若浏览器恢复了滚动位置，首帧就按当前位置呈现 */

  window.HeroFade = {
    enabled: true,
    get opacity() {
      var raw = parseFloat(root.style.getPropertyValue('--hero-fade'));
      return isNaN(raw) ? 1 : raw;
    },
    get range() { return range; },
    update: function () { measure(); apply(); }
  };
})();
