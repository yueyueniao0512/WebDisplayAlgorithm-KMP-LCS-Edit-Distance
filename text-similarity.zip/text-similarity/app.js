/* ============================================================
 * app.js
 * 页面控制器：读取输入 → 调用 SimAlgo.Similarity.analyze()（真实算法）
 * → 在同一页面并行回放 KMP / LCS / 编辑距离三份算法留下的执行轨迹。
 *
 * 说明：轨迹（steps / order / path / log）均由 algorithms/*.js 在真实
 * 计算过程中记录，本文件只负责可视化回放，不重新实现算法。
 * ============================================================ */
(function () {
  'use strict';

  var CFG = window.APP_CONFIG;
  var A = window.SimAlgo;
  var $ = function (id) { return document.getElementById(id); };
  /* 双语：T = UI 文案（{0} 占位），TR = 算法产出的中文数据串（结论 / 错误） */
  function T() {
    return (window.I18N && window.I18N.t) ? window.I18N.t.apply(window.I18N, arguments) : arguments[0];
  }
  function TR(s) {
    return (window.I18N && window.I18N.tr) ? window.I18N.tr(s) : s;
  }

  var state = {
    token: 0,
    running: false,
    animate: true,
    speed: 10,
    loop: true,
    diffCells: [],
    opEls: [],
    sourceKey: 'kmp',
    sampleId: '',
    lastResult: null,
    pendingRetranslate: false
  };

  /* ---------------- 基础工具 ---------------- */
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function fmt(n) { return Number(n).toFixed(2); }
  function sleep(ms) {
    return new Promise(function (resolve) {
      if (ms <= 0) resolve(); else setTimeout(resolve, ms);
    });
  }
  function alive(token) { return token === state.token; }
  function statGrid(items) {
    return items.map(function (it) {
      return '<div class="stat"><span class="stat__k">' + esc(it[0]) +
        '</span><span class="stat__v">' + esc(String(it[1])) + '</span></div>';
    }).join('');
  }

  /* ---------------- 初始化 ---------------- */
  function init() {
    if (!CFG || !A || !A.Similarity) {
      $('errorMsg').textContent = T('配置或算法模块未加载：请确认 config/app.config.js 与 algorithms/*.js 均已按 index.html 顺序引入。');
      return;
    }
    buildSamples();
    buildSourceTabs();
    bindEvents();
    applyDefaults();
    startClock();
    handleQuery();
  }

  function startClock() {
    var el = $('clock');
    function tick() {
      var d = new Date();
      el.textContent = [d.getHours(), d.getMinutes(), d.getSeconds()]
        .map(function (x) { return String(x).padStart(2, '0'); }).join(':');
    }
    tick(); setInterval(tick, 1000);
  }

  function applyDefaults() {
    var s = CFG.samples[0];
    $('textA').value = s.a;
    $('textB').value = s.b;
    $('optCase').checked = !!CFG.normalize.ignoreCase;
    $('optSpace').checked = !!CFG.normalize.ignoreSpaces;
    $('optPunct').checked = !!CFG.normalize.ignorePunctuation;
    $('optAnim').checked = true;
    $('optSpeed').value = '10';
    $('optLoop').checked = !!(CFG.analogy && CFG.analogy.loop !== false);
    markSample(s.id);
    updateCounts();
  }

  function buildSamples() {
    var box = $('samples');
    CFG.samples.forEach(function (s) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'chip';
      b.dataset.sample = s.id;
      b.textContent = T(s.label);
      b.addEventListener('click', function () { loadSample(s.id); });
      box.appendChild(b);
    });
  }

  function loadSample(id) {
    var s = CFG.samples.filter(function (x) { return x.id === id; })[0];
    if (!s) return;
    $('textA').value = s.a;
    $('textB').value = s.b;
    $('errorMsg').textContent = '';
    markSample(id);
    updateCounts();
  }

  function markSample(id) {
    state.sampleId = id;
    Array.prototype.forEach.call(document.querySelectorAll('#samples .chip'), function (b) {
      b.classList.toggle('is-active', b.dataset.sample === id);
    });
  }

  function updateCounts() {
    $('countA').textContent = T('{0} 字符', Array.from($('textA').value).length);
    $('countB').textContent = T('{0} 字符', Array.from($('textB').value).length);
  }

  function readOptions() {
    CFG.normalize = {
      ignoreCase: $('optCase').checked,
      ignoreSpaces: $('optSpace').checked,
      ignorePunctuation: $('optPunct').checked
    };
    state.animate = $('optAnim').checked;
    state.speed = Number($('optSpeed').value);
    state.loop = $('optLoop').checked;
  }

  function bindEvents() {
    $('runBtn').addEventListener('click', runDetection);
    $('clearBtn').addEventListener('click', function () {
      $('textA').value = ''; $('textB').value = '';
      $('errorMsg').textContent = '';
      markSample('');
      updateCounts();
      if (window.SimAnalogy) window.SimAnalogy.stopLoop();
    });
    ['textA', 'textB'].forEach(function (id) {
      $(id).addEventListener('input', updateCounts);
    });
    document.querySelectorAll('.opt input, .opt select').forEach(function (n) {
      n.addEventListener('change', readOptions);
    });
    $('optLoop').addEventListener('change', function () {
      readOptions();
      if (window.SimAnalogy) window.SimAnalogy.setLoopEnabled($('optLoop').checked);
    });
    document.addEventListener('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); runDetection(); }
    });
    /* 语言切换：重建示例 / 源码标签；已有结果则按新语言落到最终状态 */
    document.addEventListener('sim:langchange', function () {
      updateCounts();
      rebuildSamples();
      rebuildSourceTabs();
      if (state.running) {
        state.pendingRetranslate = true;
      } else {
        $('runBtn').textContent = T('运行文本相似度检测 →');
        rerenderFinal();
      }
    });
  }

  function handleQuery() {
    var q = new URLSearchParams(location.search);
    if (q.get('sample')) loadSample(q.get('sample'));
    if (q.get('speed') !== null) {
      $('optSpeed').value = q.get('speed');
      state.speed = Number(q.get('speed'));
    }
    if (q.get('loop') === '0') $('optLoop').checked = false;
    if (q.get('loop') === '1') $('optLoop').checked = true;
    if (q.get('autorun') === '1') {
      setTimeout(function () { runDetection(); }, 80);
    }
  }

  /* ---------------- 源码面板 ---------------- */
  function buildSourceTabs() {
    var defs = [
      { key: 'kmp', label: '01 / KMP' },
      { key: 'lcs', label: '02 / LCS' },
      { key: 'edit', label: T('03 / 编辑距离') },
      { key: 'similarity', label: T('04 / 编排层') }
    ];
    var box = $('sourceTabs');
    defs.forEach(function (d, i) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'source-tab' + (i === 0 ? ' is-active' : '');
      b.textContent = d.label;
      b.addEventListener('click', function () {
        Array.prototype.forEach.call(box.children, function (n) { n.classList.remove('is-active'); });
        b.classList.add('is-active');
        state.sourceKey = d.key;
        loadSource(d.key);
      });
      box.appendChild(b);
    });
    loadSource(state.sourceKey || 'kmp');
  }

  function fallbackSource(key) {
    var groups = {
      kmp: [A.KMP.buildNext, A.KMP.search, A.KMP.longestCommonSubstring, A.KMP.coverage, A.KMP.analyze],
      lcs: [A.LCS.compute],
      edit: [A.EditDistance.compute],
      similarity: [A.Similarity.tokenize, A.Similarity.analyze]
    };
    // 用 file:// 直接打开时浏览器不让读文件，就退一步：
    // 直接从内存里把「此刻正在跑的函数」原样取出来，连注释都是真的。
    var intros = {
      kmp: T('// 荧光笔那一支：做退路表 → 逐字比对 → 二分猜整块长度 → 把公共块划出来\n// 块地图：① 外壳 ② 计时 ③ 退路表 ④ 逐字比对 ⑤ 二分猜长度 ⑥ 荧光笔分块 ⑦ 总入口 ⑧ 出口'),
      lcs: T('// 两支笔连线那一支：铺 DP 成绩表 → 从右下角倒着走回去捡公共字\n// 块地图：① 外壳 ② 计时 ③ 铺表 / 填表 / 回溯（内含逐段说明） ④ 出口'),
      edit: T('// 红笔批改那一支：铺代价表 → 回溯出「保留 / 替换 / 插入 / 删除」清单\n// 块地图：① 外壳 ② 计时 ③ 代价表 / 批改清单（内含逐段说明） ④ 出口'),
      similarity: T('// 主持人：收拾文本 → 请三位检查员各算各的分 → 加权给结论\n// 块地图：① 外壳与依赖 ② 收拾文本 ③ 三位检查员打分 ④ 出口')
    };
    return T('// 用 file:// 直接打开时浏览器不允许 fetch 源文件，于是改成：\n// 从正在运行的代码里把函数原样取出来（Function.prototype.toString()），\n// 与页面上真正执行的完全一致，注释也不是另写的。') + '\n\n' +
      (intros[key] ? intros[key] + '\n\n' : '') +
      (groups[key] || []).map(function (f) {
        return '// ' + T('── 函数 {0} ──', (f.name || 'anonymous')) + '\n' + f.toString();
      }).join('\n\n');
  }

  function highlight(code) {
    /* 第一组专门认「// 【块 N】」这类块标题，单独高亮成陶土色，
       用户扫一眼就能把源码切成一段段；其余仍是普通灰色注释。 */
    var re = /(\/\/ 【块[^\n]*)|(\/\/[^\n]*|\/\*.*?\*\/)|('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|`(?:\\.|[^`\\])*`)|\b(function|return|var|let|const|if|else|for|while|break|continue|new|typeof|delete|in|of|this|null|undefined|true|false|async|await|class|extends|try|catch|throw)\b|\b(\d+(?:\.\d+)?)\b/g;
    return esc(code).split('\n').map(function (line, i) {
      var h = line.replace(re, function (m, block, com, str, kw, num) {
        if (block) return '<span class="tk-com tk-com--block">' + m + '</span>';
        if (com) return '<span class="tk-com">' + m + '</span>';
        if (str) return '<span class="tk-str">' + m + '</span>';
        if (kw) return '<span class="tk-kw">' + m + '</span>';
        if (num) return '<span class="tk-num">' + m + '</span>';
        return m;
      });
      return '<span class="ln">' + (i + 1) + '</span>' + h;
    }).join('\n');
  }

  function loadSource(key) {
    var el = $('sourceCode');
    el.innerHTML = '<code>' + esc(T('正在读取 {0} …', CFG.sources[key])) + '</code>';
    var path = CFG.sources[key];
    if (typeof fetch !== 'function' || location.protocol === 'file:') {
      el.innerHTML = '<code>' + highlight(fallbackSource(key)) + '</code>';
      return;
    }
    fetch(path, { cache: 'no-store' })
      .then(function (res) { if (!res.ok) throw new Error('HTTP ' + res.status); return res.text(); })
      .then(function (text) {
        el.innerHTML = '<code>' + highlight('// ' + path + '\n' + text) + '</code>';
      })
      .catch(function () {
        el.innerHTML = '<code>' + highlight(fallbackSource(key)) + '</code>';
      });
  }

  /* ---------------- 回放调度 ---------------- */
  function makeLogFeeder(logEl, countEl, logs) {
    var cursor = 0;
    return function (frame, total) {
      var limit = Math.min(logs.length, Math.ceil((frame + 1) / total * logs.length));
      while (cursor < limit) {
        var l = logs[cursor++];
        var li = document.createElement('li');
        li.setAttribute('data-t', l.tag);
        li.setAttribute('data-kind', l.kind || '');
        li.textContent = l.text;
        logEl.appendChild(li);
      }
      countEl.textContent = cursor;
      logEl.scrollTop = logEl.scrollHeight;
    };
  }

  function replay(frames, fn, token) {
    if (!state.animate || state.speed === 0 || frames <= 1) {
      fn(frames - 1, frames);
      return Promise.resolve(alive(token));
    }
    var f = 0;
    function step() {
      if (!alive(token)) return Promise.resolve(false);
      fn(f, frames);
      f++;
      if (f >= frames) return Promise.resolve(true);
      return sleep(state.speed).then(step);
    }
    return step();
  }

  /* ---------------- DP 矩阵构建 ---------------- */
  function buildMatrix(containerId, a, b, dp, opt) {
    var side = CFG.animation.maxRenderSide || 44;
    var rows = Math.min(a.length + 1, side);
    var cols = Math.min(b.length + 1, side);
    var maxV = 1, i, j;
    for (i = 0; i < rows; i++) {
      for (j = 0; j < cols; j++) if (dp[i][j] > maxV) maxV = dp[i][j];
    }

    var html = '<div class="mhead mhead--corner">i/j</div>';
    for (j = 0; j < cols; j++) html += '<div class="mhead">' + (j === 0 ? '0' : esc(b[j - 1])) + '</div>';
    for (i = 1; i < rows; i++) {
      html += '<div class="mhead">' + esc(a[i - 1]) + '</div>';
      for (j = 0; j < cols; j++) {
        var v = dp[i][j];
        var h = 0.06 + 0.42 * (v / maxV);
        var isMatch = opt.useMatch && i > 0 && j > 0 && a[i - 1] === b[j - 1];
        html += '<div class="mcell" data-key="' + i + '_' + j + '" data-match="' + (isMatch ? 1 : 0) +
          '" style="--h:' + h.toFixed(3) + '"><span>' + v + '</span></div>';
      }
    }

    var el = $(containerId);
    el.style.gridTemplateColumns = 'repeat(' + (cols + 1) + ', 26px)';
    el.innerHTML = html;
    var cells = {};
    el.querySelectorAll('.mcell').forEach(function (n) { cells[n.getAttribute('data-key')] = n; });
    return {
      cells: cells, rows: rows, cols: cols,
      truncated: a.length + 1 > rows || b.length + 1 > cols,
      el: el, maxV: maxV
    };
  }

  function matrixNote(mat, noteId) {
    if (mat.truncated) {
      $(noteId).textContent = T('矩阵过大，可视化仅展示前 {0} 行 × {1} 列；评分与回溯仍基于完整矩阵计算。',
        mat.rows - 1, mat.cols - 1);
      $(noteId).className = 'note note--warn';
    }
  }

  /* ---------------- 静态渲染 ---------------- */
  function renderOverview(r) {
    $('overview').hidden = false;
    $('algorithms').hidden = false;
    $('scoreNumber').textContent = r.combined.toFixed(1);
    $('verdict').textContent = TR(r.verdict);
    $('valKmp').textContent = r.results.kmp.score.toFixed(1);
    $('valLcs').textContent = r.results.lcs.score.toFixed(1);
    $('valEdit').textContent = r.results.edit.score.toFixed(1);
    var w = r.weights;
    $('formula').textContent = T('综合分 = {0} × KMP + {1} × LCS + {2} × 编辑距离　|　归一化后 |A|={3}，|B|={4}',
      w.kmp.toFixed(2), w.lcs.toFixed(2), w.edit.toFixed(2), r.meta.lenA, r.meta.lenB);
    $('statusLine').textContent = T('计算完毕 · 轨迹回放中');
    $('statusLine').className = 'status-line is-running';
    $('timings').innerHTML = T('计算耗时 {0} ms<br>轨迹回放中…', fmt(r.elapsedMs));
    requestAnimationFrame(function () {
      $('barKmp').style.width = r.results.kmp.score + '%';
      $('barLcs').style.width = r.results.lcs.score + '%';
      $('barEdit').style.width = r.results.edit.score + '%';
    });
  }

  function finishStatus(r) {
    $('statusLine').textContent = T('检测完成 · 3/3 已执行');
    $('statusLine').className = 'status-line is-done';
    $('timings').innerHTML = T('KMP  {0} ms<br>LCS  {1} ms<br>EDIT {2} ms<br>合计 {3} ms',
      fmt(r.results.kmp.elapsedMs), fmt(r.results.lcs.elapsedMs),
      fmt(r.results.edit.elapsedMs), fmt(r.elapsedMs));
  }

  function renderKMPBase(r) {
    $('kmpIdea').textContent = TR(CFG.algorithms[0].idea);
    $('kmpScore').textContent = r.score.toFixed(1);

    $('kmpNext').innerHTML = r.pattern.map(function (c, i) {
      return '<div class="next-cell" data-n="' + i + '"><span class="next-cell__ch">' + esc(c) +
        '</span><span class="next-cell__v">' + r.next[i] + '</span></div>';
    }).join('');
    $('kmpPattern').innerHTML = T('模式串 P = <b>{0}</b>　·　next = [{1}]<br>文本 T（演示窗口取前 48 字符）= {2}',
      esc(r.pattern.join('')), r.next.join(', '), esc(r.text.join('')));

    var tCells = r.text.map(function (c, i) {
      return '<div class="tcell" data-t="' + i + '"><span class="tcell__idx">' + i + '</span>' + esc(c) + '</div>';
    }).join('');
    var pCells = r.pattern.map(function (c, j) {
      return '<div class="tcell" data-p="' + j + '"><span class="tcell__idx">' + j + '</span>' + esc(c) + '</div>';
    }).join('');
    $('kmpStrip').innerHTML =
      '<div class="strip-row"><span class="strip-label">' + T('文本 T') + '</span><span class="pointer-mark" id="kmpPointerI">i = 0</span><div class="strip-cells">' + tCells + '</div></div>' +
      '<div class="strip-row"><span class="strip-label">' + T('模式 P') + '</span><span class="pointer-mark" id="kmpPointerJ">j = 0</span><div class="strip-cells">' + pCells + '</div></div>' +
      '<div class="strip-row"><span class="strip-label">' + T('动作') + '</span><span class="pointer-mark" id="kmpAction" style="min-width:260px">' + T('准备匹配…') + '</span></div>';

    $('kmpBlocks').innerHTML = r.blocks.length
      ? r.blocks.map(function (b, k) {
          return '<div class="block"><span class="block__no">#' + String(k + 1).padStart(2, '0') +
            '</span><span class="block__text">' + esc(b.text) + '</span>' +
            '<span class="block__pos">A@' + b.startA + ' ↔ B@' + b.startB + ' · len ' + b.length + '</span></div>';
        }).join('')
      : '<p class="empty-hint">' + T('未找到长度 ≥ {0} 的公共片段。', (CFG.guards.minBlockLength || 2)) + '</p>';

    var m = r.metrics;
    $('kmpStats').innerHTML = statGrid([
      [T('最长公共子串'), m.longestLength],
      [T('公共片段数'), m.blocks],
      [T('命中 / 分母'), m.matched + ' / ' + m.denom],
      [T('next 回退次数'), m.fallbacks],
      [T('字符比较总数'), m.totalComparisons],
      [T('二分验证轮次'), m.rounds]
    ]);
    $('kmpLog').innerHTML = '';
    $('kmpLogCount').textContent = '0';
    $('kmpElapsed').textContent = fmt(r.elapsedMs) + ' ms';
  }

  function renderLCSBase(r, a, b) {
    $('lcsIdea').textContent = TR(CFG.algorithms[1].idea);
    $('lcsScore').textContent = r.score.toFixed(1);
    $('lcsSeq').innerHTML = r.sequence.length
      ? r.sequence.map(function (c) { return '<span class="seq-char">' + esc(c) + '</span>'; }).join('')
      : '<p class="empty-hint">' + T('两段文本没有公共字符。') + '</p>';
    $('lcsStats').innerHTML = statGrid([
      [T('LCS 长度'), r.length],
      [T('DP 单元格'), r.metrics.cells],
      [T('相等字符格'), r.metrics.equalCells],
      [T('回溯步数'), r.metrics.pathSteps]
    ]);
    $('lcsFormula').textContent = T('相似度 = 2 × {0} / ({1} + {2}) = {3} 分。',
      r.length, a.length, b.length, r.score.toFixed(2));
    $('lcsFormula').className = 'note';
    $('lcsLog').innerHTML = '';
    $('lcsLogCount').textContent = '0';
    $('lcsElapsed').textContent = fmt(r.elapsedMs) + ' ms';
    return buildMatrix('lcsMatrix', a, b, r.dp, { useMatch: true });
  }

  function renderEditBase(r, a, b) {
    $('editIdea').textContent = TR(CFG.algorithms[2].idea);
    $('editScore').textContent = r.score.toFixed(1);

    var ops = r.alignment;
    var html = '<div class="diff-row"><span class="dcell dcell--label">A</span>' +
      ops.map(function (o) {
        return '<span class="dcell ' + (o.a == null ? 'is-gap ' : '') + 'op-' + o.type + '">' + esc(o.a == null ? '·' : o.a) + '</span>';
      }).join('') + '</div>' +
      '<div class="diff-row"><span class="dcell dcell--label">B</span>' +
      ops.map(function (o) {
        return '<span class="dcell ' + (o.b == null ? 'is-gap ' : '') + 'op-' + o.type + '">' + esc(o.b == null ? '·' : o.b) + '</span>';
      }).join('') + '</div>' +
      '<div class="diff-row"><span class="dcell dcell--label">OP</span>' +
      ops.map(function (o) {
        var sym = { match: '=', sub: '~', ins: '+', del: '−' }[o.type];
        return '<span class="dcell op-' + o.type + '">' + sym + '</span>';
      }).join('') + '</div>';

    var grid = $('editDiff');
    grid.style.gridTemplateColumns = '44px repeat(' + ops.length + ', 27px)';
    grid.innerHTML = html;
    state.diffCells = Array.prototype.slice.call(grid.querySelectorAll('.dcell:not(.dcell--label)'));
    state.diffCells.forEach(function (n) { n.style.opacity = '0'; });

    $('editOps').innerHTML = r.ops.length
      ? r.ops.map(function (o) {
          return '<span class="op" data-type="' + o.type + '">' + T(o.type) +
            (o.type === '插入' ? ' ' + esc(o.b) : ' ' + esc(o.a) + (o.type === '替换' ? '→' + esc(o.b) : '')) + '</span>';
        }).join('')
      : '<span class="empty-hint">' + T('无需任何编辑操作') + '</span>';
    state.opEls = Array.prototype.slice.call($('editOps').querySelectorAll('.op'));
    state.opEls.forEach(function (n) { n.style.opacity = '.15'; });

    $('editStats').innerHTML = statGrid([
      [T('编辑距离'), r.distance],
      [T('替换'), r.counts['替换']],
      [T('插入'), r.counts['插入']],
      [T('删除'), r.counts['删除']],
      [T('保留'), r.counts['保留']]
    ]);
    $('editFormula').textContent = T('相似度 = (1 − {0} / {1}) × 100 = {2} 分。',
      r.distance, Math.max(a.length, b.length, 1), r.score.toFixed(2));
    $('editFormula').className = 'note';
    $('editLog').innerHTML = '';
    $('editLogCount').textContent = '0';
    $('editElapsed').textContent = fmt(r.elapsedMs) + ' ms';
    return buildMatrix('editMatrix', a, b, r.dp, { useMatch: false });
  }

  /* ---------------- 轨迹回放：KMP ---------------- */
  function animateKMP(r, token) {
    var steps = r.steps || [];
    var frames = Math.max(1, Math.min(90, steps.length));
    var feed = makeLogFeeder($('kmpLog'), $('kmpLogCount'), r.log);
    var strip = $('kmpStrip');
    var tEls = strip.querySelectorAll('[data-t]');
    var pEls = strip.querySelectorAll('[data-p]');
    var nextEls = $('kmpNext').querySelectorAll('.next-cell');
    var li = $('kmpPointerI'), lj = $('kmpPointerJ'), la = $('kmpAction');

    function clearTransient() {
      var k;
      for (k = 0; k < tEls.length; k++) tEls[k].classList.remove('is-pointer', 'is-equal', 'is-fallback');
      for (k = 0; k < pEls.length; k++) pEls[k].classList.remove('is-pointer', 'is-equal', 'is-fallback');
      for (k = 0; k < nextEls.length; k++) nextEls[k].classList.remove('is-active');
    }

    return replay(frames, function (f, total) {
      feed(f, total);
      clearTransient();
      if (!steps.length) return;
      var idx = Math.min(steps.length - 1, Math.floor((f + 1) / total * steps.length) - 1);
      if (idx < 0) return;
      var s = steps[idx];
      var tc = tEls[s.i], pc = pEls[s.j];
      if (s.action === 'match') {
        if (tc) { tc.classList.add('is-pointer', 'is-equal'); }
        if (pc) pc.classList.add('is-equal');
        la.textContent = T('比较 T[{0}]={1} 与 P[{2}]={3} → 相等，i/j 同时前进', s.i, s.textChar, s.j, s.patternChar);
      } else if (s.action === 'fallback') {
        if (tc) tc.classList.add('is-pointer');
        if (pc) pc.classList.add('is-fallback');
        la.textContent = T('失配 → 查 next 回退 j: {0} → {1}，i 不动', s.from, s.to);
      } else if (s.action === 'found') {
        for (var k = s.start; k < s.start + r.pattern.length && k < tEls.length; k++) tEls[k].classList.add('is-hit');
        la.textContent = T('命中！模式串在 T[{0}] 处完整匹配', s.start);
      } else {
        if (tc) tc.classList.add('is-pointer');
        la.textContent = T('j=0 且失配 → i 前进到 {0}', s.i + 1);
      }
      if (nextEls[s.j]) nextEls[s.j].classList.add('is-active');
      li.textContent = 'i = ' + s.i;
      lj.textContent = 'j = ' + s.j;
    }, token).then(function (ok) {
      if (!ok || !alive(token)) return;
      clearTransient();
      (r.matches || []).forEach(function (start) {
        for (var k = start; k < start + r.pattern.length && k < tEls.length; k++) tEls[k].classList.add('is-hit');
      });
      la.textContent = T('运行结束：{0} 次比较，{1} 次回退，命中 {2} 处',
        r.metrics.demoComparisons, r.metrics.fallbacks, (r.matches || []).length);
      feed(frames - 1, frames);
    });
  }

  /* ---------------- 轨迹回放：DP 矩阵通用 ---------------- */
  function animateMatrix(r, mat, token, extras) {
    var frames = 90;
    var feed = makeLogFeeder(
      $(r.id === 'lcs' ? 'lcsLog' : 'editLog'),
      $(r.id === 'lcs' ? 'lcsLogCount' : 'editLogCount'),
      r.log
    );
    var order = r.order.filter(function (o) { return o.i < mat.rows && o.j < mat.cols; });
    var revealed = 0, lastCurrent = null;
    var extrasFn = extras || function () {};

    return replay(frames, function (f, total) {
      feed(f, total);
      var p = (f + 1) / total;
      var upto = Math.min(order.length, Math.ceil(p * order.length));
      while (revealed < upto) {
        var o = order[revealed++];
        var cell = mat.cells[o.i + '_' + o.j];
        if (cell) {
          cell.classList.add('is-filled');
          if (o.match && cell.getAttribute('data-match') === '1') cell.classList.add('is-match');
        }
      }
      if (lastCurrent) lastCurrent.classList.remove('is-current');
      if (upto > 0) {
        var last = order[upto - 1];
        lastCurrent = mat.cells[last.i + '_' + last.j];
        if (lastCurrent) lastCurrent.classList.add('is-current');
      }
      extrasFn(p, f, total);
    }, token).then(function (ok) {
      if (!ok || !alive(token)) return;
      if (lastCurrent) lastCurrent.classList.remove('is-current');
      r.path.forEach(function (p) {
        var cell = mat.cells[p.i + '_' + p.j];
        if (cell) cell.classList.add('is-path');
      });
      for (var k = 0; k < order.length; k++) {
        var o = order[k];
        var c = mat.cells[o.i + '_' + o.j];
        if (c) {
          c.classList.add('is-filled');
          if (o.match && c.getAttribute('data-match') === '1') c.classList.add('is-match');
        }
      }
      extrasFn(1, frames - 1, frames);
      feed(frames - 1, frames);
    });
  }

  function animateLCS(r, mat, token) {
    var seqEls = $('lcsSeq').querySelectorAll('.seq-char');
    return animateMatrix(r, mat, token, function (p) {
      var upto = Math.ceil(p * seqEls.length);
      for (var k = 0; k < seqEls.length; k++) seqEls[k].classList.toggle('is-in', k < upto);
    });
  }

  function animateEdit(r, mat, token) {
    return animateMatrix(r, mat, token, function (p) {
      var d = Math.ceil(p * state.diffCells.length);
      for (var k = 0; k < state.diffCells.length; k++) state.diffCells[k].style.opacity = k < d ? '1' : '0';
      var o = Math.ceil(p * state.opEls.length);
      for (var q = 0; q < state.opEls.length; q++) state.opEls[q].style.opacity = q < o ? '1' : '.15';
    });
  }

  /* ---------------- 语言切换支持 ---------------- */
  function rebuildSamples() {
    $('samples').querySelectorAll('.chip').forEach(function (n) { n.remove(); });
    buildSamples();
    markSample(state.sampleId);
  }
  function rebuildSourceTabs() {
    $('sourceTabs').innerHTML = '';
    buildSourceTabs();        /* 会按 state.sourceKey 重新加载源码 */
  }
  function fillLogsAll(logId, countId, logs) {
    var logEl = $(logId);
    logEl.innerHTML = '';
    (logs || []).forEach(function (l) {
      var li = document.createElement('li');
      li.setAttribute('data-t', l.tag);
      li.setAttribute('data-kind', l.kind || '');
      li.textContent = l.text;
      logEl.appendChild(li);
    });
    $(countId).textContent = (logs || []).length;
    logEl.scrollTop = logEl.scrollHeight;
  }
  function finalizeMatrix(r, mat) {
    r.order.forEach(function (o) {
      var c = mat.cells[o.i + '_' + o.j];
      if (c) {
        c.classList.add('is-filled');
        if (o.match && c.getAttribute('data-match') === '1') c.classList.add('is-match');
      }
    });
    r.path.forEach(function (p) {
      var c = mat.cells[p.i + '_' + p.j];
      if (c) c.classList.add('is-path');
    });
  }
  /* 语言切换后（不在检测中）把所有面板按新语言直接落到最终状态 */
  function rerenderFinal() {
    var r = state.lastResult;
    if (!r) return;
    renderOverview(r);
    renderKMPBase(r.results.kmp);
    var lcsMat = renderLCSBase(r.results.lcs, r.a, r.b);
    var editMat = renderEditBase(r.results.edit, r.a, r.b);
    matrixNote(lcsMat, 'lcsFormula');
    matrixNote(editMat, 'editFormula');
    finalizeMatrix(r.results.lcs, lcsMat);
    finalizeMatrix(r.results.edit, editMat);
    Array.prototype.forEach.call($('lcsSeq').querySelectorAll('.seq-char'), function (n) {
      n.classList.add('is-in');
    });
    var tEls = $('kmpStrip').querySelectorAll('[data-t]');
    (r.results.kmp.matches || []).forEach(function (start) {
      for (var k = start; k < start + r.results.kmp.pattern.length && k < tEls.length; k++) {
        tEls[k].classList.add('is-hit');
      }
    });
    var la = $('kmpAction');
    if (la) {
      la.textContent = T('运行结束：{0} 次比较，{1} 次回退，命中 {2} 处',
        r.results.kmp.metrics.demoComparisons, r.results.kmp.metrics.fallbacks,
        (r.results.kmp.matches || []).length);
    }
    state.diffCells.forEach(function (n) { n.style.opacity = '1'; });
    state.opEls.forEach(function (n) { n.style.opacity = '1'; });
    fillLogsAll('kmpLog', 'kmpLogCount', r.results.kmp.log);
    fillLogsAll('lcsLog', 'lcsLogCount', r.results.lcs.log);
    fillLogsAll('editLog', 'editLogCount', r.results.edit.log);
    finishStatus(r);
  }

  /* ---------------- 主流程 ---------------- */
  function runDetection() {
    if (state.running) return Promise.resolve();
    if (window.SimAnalogy) window.SimAnalogy.stopLoop();  /* 打断上一轮自动循环 */
    readOptions();
    $('errorMsg').textContent = '';

    var result = A.Similarity.analyze($('textA').value, $('textB').value, CFG);
    if (result.error) {
      $('errorMsg').textContent = TR(result.error);
      return Promise.resolve();
    }
    if (!result.results.kmp || !result.results.lcs || !result.results.edit) {
      $('errorMsg').textContent = T('算法返回结果不完整。');
      return Promise.resolve();
    }

    var token = ++state.token;
    state.running = true;
    state.lastResult = result;
    $('runBtn').disabled = true;
    $('runBtn').textContent = T('运行中…');

    renderOverview(result);
    renderKMPBase(result.results.kmp);
    var lcsMat = renderLCSBase(result.results.lcs, result.a, result.b);
    var editMat = renderEditBase(result.results.edit, result.a, result.b);
    matrixNote(lcsMat, 'lcsFormula');
    matrixNote(editMat, 'editFormula');

    /* 每次检测都重新搭建并并行播放三段「直观演示」动画 */
    var analogyOn = !!(window.SimAnalogy && CFG.analogy && CFG.analogy.enabled !== false);
    if (analogyOn) window.SimAnalogy.prepare(result);

    return Promise.all([
      animateKMP(result.results.kmp, token),
      animateLCS(result.results.lcs, lcsMat, token),
      animateEdit(result.results.edit, editMat, token),
      analogyOn ? window.SimAnalogy.play(result, {
        speed: state.speed,
        animate: state.animate,
        alive: function () { return alive(token); }
      }) : Promise.resolve()
    ]).then(function () {
      if (!alive(token)) return;
      state.running = false;
      $('runBtn').disabled = false;
      $('runBtn').textContent = T('运行文本相似度检测 →');
      finishStatus(result);
      /* 检测期间切了语言：按新语言把面板落到最终状态 */
      if (state.pendingRetranslate) { state.pendingRetranslate = false; rerenderFinal(); }
      /* 三段演示进入自动循环：只重播，不重算，也不占用运行按钮 */
      if (analogyOn && window.SimAnalogy) {
        window.SimAnalogy.startLoop(result, {
          speed: state.speed,
          animate: state.animate,
          loop: state.loop,
          alive: function () { return alive(token); }
        });
      }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
