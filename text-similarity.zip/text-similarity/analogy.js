/* ============================================================
 * analogy.js
 * 「直观演示」动画控制器 —— 把三种算法翻译成三个看得见的动作：
 *
 *   ① KMP      → 荧光笔：把「连着、一字不差」的整块从左到右涂亮
 *   ② LCS      → 两支笔：A、B 两行之间逐根划连线，允许跳字、线不交叉
 *   ③ 编辑距离 → 红笔批改：逐笔替换 / 插入 / 删除，实时数「改了几处」
 *
 * 重要：本文件不实现任何算法，全部动画数据来自 algorithms/*.js 的
 * 真实计算结果（blocks / path / alignment），每次运行检测都会重新播放。
 * ============================================================ */
(function () {
  'use strict';

  var CFG = window.APP_CONFIG || {};
  var $ = function (id) { return document.getElementById(id); };
  var SVG_NS = 'http://www.w3.org/2000/svg';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function T() {
    return (window.I18N && window.I18N.t) ? window.I18N.t.apply(window.I18N, arguments) : arguments[0];
  }
  function conf() {
    return CFG.analogy || {
      maxChars: 28, frames: 70, speedFactor: 1.6, enabled: true,
      loop: true, loopDelayMs: 1600, pauseWhenHidden: true
    };
  }
  function maxChars() { return conf().maxChars || 28; }
  function maxFrames() { return conf().frames || 70; }

  /* 三个演示共用一个「文字窗口」：文本过长时把第一处改动挪进可视区，便于对照 */
  var currentWindow = { start: 0, end: 28, max: 28 };
  var lastResult = null;

  function chooseWindow(result) {
    var max = maxChars();
    var a = result.a, b = result.b;
    if (a.length <= max && b.length <= max) return { start: 0, end: max, max: max };
    var ai = 0, first = -1;
    (result.results.edit.alignment || []).some(function (o) {
      if (o.type !== 'match') { first = ai; return true; }
      if (o.a != null) ai++;
      return false;
    });
    if (first < 0) first = 0;
    var limit = Math.max(0, Math.max(a.length, b.length) - max);
    var start = Math.max(0, Math.min(first - 10, limit));
    return { start: start, end: start + max, max: max };
  }

  /* data-* 存的是「全文绝对下标」，窗口外的字不会被渲染，动画自然跳过 */
  function charRow(label, chars, attr, win) {
    return '<div class="arow"><span class="arow__label">' + esc(label) + '</span>' +
      '<div class="arow__cells">' +
      chars.slice(win.start, win.end).map(function (c, i) {
        return '<span class="achar" data-' + attr + '="' + (win.start + i) + '">' + esc(c) + '</span>';
      }).join('') +
      '</div></div>';
  }

  function indexMap(stage, attr) {
    var map = {};
    stage.querySelectorAll('[data-' + attr + ']').forEach(function (n) {
      map[n.getAttribute('data-' + attr)] = n;
    });
    return map;
  }

  /* 每帧回调；speed=0 或关闭动画时直接落到最终状态 */
  function replay(frames, fn, ctl) {
    if (!ctl.animate || ctl.speed === 0 || frames <= 1) {
      fn(frames - 1, frames);
      return Promise.resolve();
    }
    var f = 0;
    function step() {
      if (!ctl.alive()) return Promise.resolve();
      fn(f, frames);
      f++;
      if (f >= frames) return Promise.resolve();
      return new Promise(function (r) { setTimeout(r, ctl.speed); }).then(step);
    }
    return step();
  }

  /* ---------------- 准备：每次检测重新构建演示舞台 ---------------- */
  function prepare(result) {
    lastResult = result;
    var a = result.a, b = result.b;
    var win = chooseWindow(result);
    currentWindow = win;
    var truncated = a.length > win.max || b.length > win.max;

    $('kmpAnalogyStage').innerHTML =
      charRow('A', a, 'a', win) + charRow('B', b, 'b', win);
    $('lcsAnalogyStage').innerHTML =
      '<svg class="asvg" id="lcsSvg" aria-hidden="true"></svg>' +
      charRow('A', a, 'a', win) + charRow('B', b, 'b', win);
    $('editAnalogyStage').innerHTML =
      charRow(T('A 原文'), a, 'a', win) + charRow(T('B 结果'), b, 'b', win) +
      '<div class="acounter">' + T('红笔已落下 <b id="editRedCount">0</b> 笔') +
      '<span id="editRedLabel">' + T('（等待批改…）') + '</span></div>';

    $('kmpAnalogyStatus').textContent = T('等待检测…');
    $('lcsAnalogyStatus').textContent = T('等待检测…');
    $('editAnalogyStatus').textContent = T('等待检测…');

    Array.prototype.forEach.call(document.querySelectorAll('.analogy__hint'), function (h) {
      if (!h.getAttribute('data-base')) h.setAttribute('data-base', h.innerHTML);
      h.innerHTML = h.getAttribute('data-base') + (truncated
        ? ' <span class="note note--warn">' + T('（文本较长，演示区只显示第 {0}–{1} 个字符；评分仍按全文计算）',
            win.start + 1, Math.min(win.end, Math.max(a.length, b.length))) + '</span>'
        : '');
    });
  }

  /* ---------------- ① KMP：荧光笔划整块 ---------------- */
  function playKMP(r, result, ctl) {
    var win = currentWindow;
    var stage = $('kmpAnalogyStage');
    var status = $('kmpAnalogyStatus');
    var aMap = indexMap(stage, 'a');
    var bMap = indexMap(stage, 'b');

    var blocks = (r.blocks || []).filter(function (b) {
      return b.startA < win.end && b.startB < win.end &&
             b.startA + b.length > win.start && b.startB + b.length > win.start;
    });
    var fallback = false;
    /* 没有达到「成块」门槛时，退回到最长公共子串，仅作展示 */
    if (!blocks.length && r.longest && r.longest.length && r.longest.posA >= 0) {
      blocks = [{
        text: r.longest.substring.join(''),
        startA: r.longest.posA, startB: r.longest.posB, length: r.longest.length
      }];
      fallback = true;
    }

    var steps = [];
    blocks.forEach(function (blk, k) {
      for (var t = 0; t < blk.length; t++) {
        steps.push({ k: k, ai: blk.startA + t, bi: blk.startB + t, blk: blk });
      }
    });
    if (!steps.length) {
      status.textContent = T('没有找到一模一样的整块（0 处）');
      return Promise.resolve();
    }

    var frames = Math.max(1, Math.min(maxFrames(), steps.length));
    var done = 0, brushing = [], marked = 0;

    return replay(frames, function (f, total) {
      var upto = Math.min(steps.length, Math.ceil((f + 1) / total * steps.length));
      brushing.forEach(function (n) { n.classList.remove('is-brushing'); });
      brushing = [];
      while (done < upto) {
        var s = steps[done++];
        var x = aMap[s.ai], y = bMap[s.bi];
        if (x) { x.classList.add('is-marked', 'is-brushing'); brushing.push(x); marked++; }
        if (y) { y.classList.add('is-marked', 'is-brushing'); brushing.push(y); }
      }
      var cur = steps[upto - 1];
      status.textContent = T('第 {0} 块｜正在划「{1}」', cur.k + 1, cur.blk.text);
    }, ctl).then(function () {
      if (!ctl.alive()) return;   /* 已被新检测 / 新循环打断，不覆盖新一轮状态 */
      brushing.forEach(function (n) { n.classList.remove('is-brushing'); });
      var minBlock = (CFG.guards && CFG.guards.minBlockLength) || 2;
      status.textContent = T('完成｜划出 {0} 块，演示区标记 {1} 个字', blocks.length, marked) +
        (fallback ? T('（算法要求 ≥{0} 字成块，此处仅展示最长公共子串）', minBlock) : '');
    });
  }

  /* ---------------- ② LCS：两支笔逐根划连线 ---------------- */
  function playLCS(r, result, ctl) {
    var win = currentWindow;
    var stage = $('lcsAnalogyStage');
    var svg = $('lcsSvg');
    var status = $('lcsAnalogyStatus');
    var aMap = indexMap(stage, 'a');
    var bMap = indexMap(stage, 'b');

    svg.innerHTML = '';
    var w = stage.offsetWidth || 1, h = stage.offsetHeight || 1;
    svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    svg.setAttribute('width', w);
    svg.setAttribute('height', h);

    /* path 是回溯得到的（右下→左上），反转后即为「从开头往后」的正向顺序 */
    var pairs = (r.path || [])
      .filter(function (p) { return p.type === 'match'; })
      .slice().reverse()
      .map(function (p) { return { a: p.i - 1, b: p.j - 1 }; })
      .filter(function (p) {
        return p.a >= win.start && p.b >= win.start &&
               p.a < win.end && p.b < win.end && aMap[p.a] && bMap[p.b];
      });

    if (!pairs.length) {
      status.textContent = T('一个字都对不上（0 根线）');
      return Promise.resolve();
    }

    var instant = !ctl.animate || ctl.speed === 0;
    var frames = Math.max(1, Math.min(maxFrames(), pairs.length));
    var drawn = 0;

    function draw(p) {
      var ae = aMap[p.a], be = bMap[p.b];
      var s = stage.getBoundingClientRect();
      var ra = ae.getBoundingClientRect(), rb = be.getBoundingClientRect();
      var x1 = ra.left - s.left + ra.width / 2, y1 = ra.bottom - s.top;
      var x2 = rb.left - s.left + rb.width / 2, y2 = rb.top - s.top;
      var mid = (y1 + y2) / 2;

      var path = document.createElementNS(SVG_NS, 'path');
      path.setAttribute('class', 'aline');
      path.setAttribute('d', 'M ' + x1 + ' ' + y1 +
        ' C ' + x1 + ' ' + mid + ', ' + x2 + ' ' + mid + ', ' + x2 + ' ' + y2);
      svg.appendChild(path);

      var len = 800;
      try { len = path.getTotalLength() || 800; } catch (e) { /* 兜底 */ }
      path.style.strokeDasharray = len;
      path.style.strokeDashoffset = instant ? 0 : len;
      if (!instant) {
        requestAnimationFrame(function () {
          path.style.transition = 'stroke-dashoffset ' + Math.max(180, ctl.speed * 14) + 'ms ease';
          path.style.strokeDashoffset = '0';
        });
      }
      ae.classList.add('is-linked');
      be.classList.add('is-linked');
    }

    return replay(frames, function (f, total) {
      var upto = Math.min(pairs.length, Math.ceil((f + 1) / total * pairs.length));
      while (drawn < upto) draw(pairs[drawn++]);
      status.textContent = T('第 {0} / {1} 根线｜已连上 {0} 个字', upto, pairs.length);
    }, ctl).then(function () {
      if (!ctl.alive()) return;
      while (drawn < pairs.length) draw(pairs[drawn++]);
      status.textContent = T('完成｜共 {0} 根线，互不交叉（顺序一致）', pairs.length);
    });
  }

  /* ---------------- ③ 编辑距离：红笔批改，逐笔计数 ---------------- */
  function playEdit(r, result, ctl) {
    var win = currentWindow;
    var stage = $('editAnalogyStage');
    var status = $('editAnalogyStatus');
    var counter = $('editRedCount');
    var label = $('editRedLabel');
    var aMap = indexMap(stage, 'a');
    var bMap = indexMap(stage, 'b');

    var names = { match: T('保留'), sub: T('替换'), ins: T('插入'), del: T('删除') };
    var ai = 0, bi = 0;
    var steps = (r.alignment || []).map(function (o) {
      var s = { type: o.type, cost: o.cost || 0, a: -1, b: -1, charA: o.a, charB: o.b };
      if (o.a != null) { s.a = (ai >= win.start && ai < win.end) ? ai : -1; ai++; }
      if (o.b != null) { s.b = (bi >= win.start && bi < win.end) ? bi : -1; bi++; }
      return s;
    });

    if (!steps.length) {
      status.textContent = T('两篇完全一样，一笔都不用改');
      label.textContent = T(' · 编辑距离 = 0');
      return Promise.resolve();
    }

    var frames = Math.max(1, Math.min(maxFrames(), steps.length));
    var done = 0, cost = 0, nowEls = [];

    return replay(frames, function (f, total) {
      var upto = Math.min(steps.length, Math.ceil((f + 1) / total * steps.length));
      nowEls.forEach(function (n) { n.classList.remove('is-now'); });
      nowEls = [];
      while (done < upto) {
        var s = steps[done++];
        cost += s.cost;
        var ae = s.a >= 0 ? aMap[s.a] : null;
        var be = s.b >= 0 ? bMap[s.b] : null;
        if (s.type === 'match') {
          if (ae) ae.classList.add('is-kept');
          if (be) be.classList.add('is-kept');
        } else if (s.type === 'sub') {
          if (ae) { ae.classList.add('is-struck', 'is-now'); nowEls.push(ae); }
          if (be) { be.classList.add('is-written', 'is-now'); nowEls.push(be); }
        } else if (s.type === 'del') {
          if (ae) { ae.classList.add('is-struck', 'is-now'); nowEls.push(ae); }
        } else {
          if (be) { be.classList.add('is-written', 'is-now'); nowEls.push(be); }
        }
      }
      counter.textContent = cost;
      var cur = steps[upto - 1];
      var detail = cur.type === 'ins' ? '「+' + cur.charB + '」'
                 : cur.type === 'del' ? '「−' + cur.charA + '」'
                 : cur.type === 'sub' ? '「' + cur.charA + '→' + cur.charB + '」'
                 : '「' + cur.charA + '」';
      label.textContent = T(' · 当前：{0}', names[cur.type] + detail);
      status.textContent = T('红笔第 {0} 步 / 共 {1} 步', upto, steps.length);
    }, ctl).then(function () {
      if (!ctl.alive()) return;
      nowEls.forEach(function (n) { n.classList.remove('is-now'); });
      counter.textContent = r.distance;
      label.textContent = T(' · 这就是最少改动次数');
      status.textContent = T('批改完成｜最少只需 {0} 笔', r.distance);
    });
  }

  /* ---------------- 对外入口 ---------------- */
  function play(result, control) {
    var c = control || {};
    var base = (typeof c.speed === 'number') ? c.speed : 10;
    var factor = conf().speedFactor || 1.6;
    var ctl = {
      speed: Math.max(0, Math.round(base * factor)),
      animate: c.animate !== false,
      alive: c.alive || function () { return true; }
    };
    return Promise.all([
      playKMP(result.results.kmp, result, ctl),
      playLCS(result.results.lcs, result, ctl),
      playEdit(result.results.edit, result, ctl)
    ]);
  }

  /* ---------------- 自动循环重播 ----------------
   * 只重播「演示」，不重算算法：每遍开始前 prepare() 把舞台恢复空白，
   * 再 play() 消费同一份真实算法结果。循环不占用 app.js 的 running 状态，
   * 因此「运行检测」按钮始终可用，随时能打断旧循环。
   * ------------------------------------------------ */
  var loop = {
    timer: 0,
    token: 0,        // 每次启动 / 停止自增，旧一轮的异步回调据此自行退出
    running: false,
    rounds: 0,
    enabled: true,
    result: null,
    opts: null
  };

  function loopDelay() { return Math.max(500, conf().loopDelayMs || 1600); }
  function hiddenPause() { return conf().pauseWhenHidden !== false && document.hidden; }

  function badge(on, n) {
    var el = $('loopBadge');
    if (!el) return;
    el.textContent = !on ? T('自动循环 · 已停止')
      : (n ? T('自动循环 · 第 {0} 遍', n) : T('自动循环 · 待命重播'));
    el.classList.toggle('is-on', !!on);
  }

  function halt() {
    loop.token++;
    loop.running = false;
    if (loop.timer) { clearTimeout(loop.timer); loop.timer = 0; }
    badge(false);
  }

  /* 一轮：重置舞台 → 播放 → 停顿 → 下一轮 */
  function round(myToken) {
    if (myToken !== loop.token || !loop.running || !loop.result) return;
    if (hiddenPause()) {                    // 后台不空转，稍后再试
      loop.timer = setTimeout(function () { round(myToken); }, 700);
      return;
    }
    prepare(loop.result);
    loop.rounds++;
    badge(true, loop.rounds);
    Promise.resolve(play(loop.result, loop.opts)).then(function () {
      if (myToken !== loop.token || !loop.running) return;
      loop.timer = setTimeout(function () { round(myToken); }, loopDelay());
    }, halt);
  }

  function setLoopEnabled(on) {
    loop.enabled = !!on;
    if (!on) { halt(); return; }
    if (!loop.result || loop.running) return;
    loop.running = true;
    badge(true, 0);
    var myToken = ++loop.token;
    loop.timer = setTimeout(function () { round(myToken); }, loopDelay());
  }

  function stopLoop() {
    halt();
    loop.result = null;
    loop.opts = null;
    loop.rounds = 0;
  }

  function startLoop(result, control) {
    halt();
    loop.result = result;
    loop.rounds = 0;
    loop.opts = {
      speed: control.speed,
      animate: true,
      alive: control.alive
    };
    var reduced = window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var allowed = loop.enabled && conf().loop !== false &&
      control.loop !== false && control.animate !== false &&
      control.speed > 0 && !reduced;
    if (allowed) setLoopEnabled(true);
    else badge(false);
  }

  function loopState() {
    return { running: loop.running, rounds: loop.rounds, enabled: loop.enabled };
  }

  /* 语言切换：循环暂停时把三段演示按新语言即时落到最终状态；
     正在循环则下一轮自动使用新语言，只刷新徽标文字。 */
  document.addEventListener('sim:langchange', function () {
    /* i18n 已按新语言重写演示提示，清掉旧的原文缓存，让 prepare 重新捕获 */
    Array.prototype.forEach.call(document.querySelectorAll('.analogy__hint'), function (h) {
      h.removeAttribute('data-base');
    });
    if (loop.running) { badge(true, loop.rounds); return; }
    if (lastResult) {
      prepare(lastResult);
      play(lastResult, { speed: 0, animate: false, alive: function () { return true; } });
    } else {
      badge(loop.enabled);
    }
  });

  window.SimAnalogy = {
    prepare: prepare, play: play,
    startLoop: startLoop, stopLoop: stopLoop,
    setLoopEnabled: setLoopEnabled, loopState: loopState
  };
})();
