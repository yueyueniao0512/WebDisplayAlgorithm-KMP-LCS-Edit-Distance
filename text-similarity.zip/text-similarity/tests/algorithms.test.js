/* ============================================================
 * tests/algorithms.test.js
 * 对「页面实际运行的算法代码」做 Node 侧正确性自检
 * 运行： npm test   或   node tests/algorithms.test.js
 * ============================================================ */
'use strict';

const assert = require('node:assert/strict');
const path = require('node:path');

const root = path.join(__dirname, '..');
const cfg = require(path.join(root, 'config/app.config.js'));
const KMP = require(path.join(root, 'algorithms/kmp.js'));
const LCS = require(path.join(root, 'algorithms/lcs.js'));
const Edit = require(path.join(root, 'algorithms/edit-distance.js'));
const Sim = require(path.join(root, 'algorithms/similarity.js'));

let passed = 0;
function check(name, fn) {
  fn();
  passed++;
  console.log('  ✓ ' + name);
}
const T = (s) => Array.from(s);

console.log('\n文本相似度检测 · 算法自检\n');

check('配置权重之和为 1', () => {
  const w = cfg.weights;
  assert.ok(Math.abs(w.kmp + w.lcs + w.edit - 1) < 1e-9, '权重必须归一化');
});

check('KMP next 前缀表：ABABAC → [0,0,1,2,3,0]', () => {
  assert.deepEqual(KMP.buildNext(T('ABABAC')).next, [0, 0, 1, 2, 3, 0]);
});

check('KMP 匹配：ABABABAC 中 ABABAC 命中位置 2', () => {
  const r = KMP.search(T('ABABABAC'), T('ABABAC'));
  assert.deepEqual(r.matches, [2]);
  assert.ok(r.fallbacks > 0, '应发生 next 回退');
  assert.ok(r.steps.length > 0, '应留下可回放的轨迹');
});

check('KMP 最长公共子串：abcde / xbcdy → bcd', () => {
  const r = KMP.longestCommonSubstring(T('abcde'), T('xbcdy'));
  assert.equal(r.length, 3);
  assert.equal(r.substring.join(''), 'bcd');
  assert.equal(r.posA, 1);
  assert.equal(r.posB, 1);
});

check('KMP 覆盖率：近似中文文本得分 > 70', () => {
  const s = cfg.samples[0];
  const r = KMP.analyze(T(s.a), T(s.b), cfg);
  assert.ok(r.score > 70, '实际得分 ' + r.score.toFixed(2));
  assert.ok(r.blocks.length > 0);
  assert.ok(r.next.length > 0);
});

check('LCS：ABCBDAB / BDCABA 长度为 4', () => {
  const r = LCS.compute(T('ABCBDAB'), T('BDCABA'), cfg);
  assert.equal(r.length, 4);
  assert.equal(r.dp[7][6], 4);
  assert.equal(r.sequence.length, 4);
});

check('LCS：完全相同文本相似度 = 100', () => {
  const s = cfg.samples[1];
  const r = LCS.compute(T(s.a), T(s.b), cfg);
  assert.equal(r.score, 100);
});

check('编辑距离：kitten → sitting = 3', () => {
  const r = Edit.compute(T('kitten'), T('sitting'), cfg);
  assert.equal(r.distance, 3);
  assert.equal(r.counts['替换'] + r.counts['插入'] + r.counts['删除'], 3);
});

check('编辑距离：flaw → lawn = 2，且对齐长度一致', () => {
  const r = Edit.compute(T('flaw'), T('lawn'), cfg);
  assert.equal(r.distance, 2);
  assert.equal(r.alignment.length, r.ops.length);
});

check('综合：相同文本 100 分 / 判定「高度相似」', () => {
  const s = cfg.samples[1];
  const r = Sim.analyze(s.a, s.b, cfg);
  assert.equal(r.error, undefined);
  assert.ok(Math.abs(r.combined - 100) < 1e-6, '实际 ' + r.combined);
  assert.equal(r.verdict, '高度相似');
});

check('综合：差异较大文本得分 < 35', () => {
  const s = cfg.samples[2];
  const r = Sim.analyze(s.a, s.b, cfg);
  assert.ok(r.combined < 35, '实际 ' + r.combined.toFixed(2));
  assert.equal(r.verdict, '差异较大');
});

check('归一化：忽略大小写 / 标点 / emoji 不拆分', () => {
  const opts = { ignoreCase: true, ignorePunctuation: true, ignoreSpaces: true };
  assert.deepEqual(Sim.tokenize('A， b！', opts), ['a', 'b']);
  assert.equal(Sim.tokenize('😀a').length, 2);
});

check('保护：超长输入返回明确错误而非卡死', () => {
  const r = Sim.analyze('字'.repeat(700), '字'.repeat(700), cfg);
  assert.ok(r.error && r.error.includes('不得超过'));
});

console.log('\n全部 ' + passed + ' 项通过。\n');
