/* ============================================================
 * scroll-anchor.js  ·  PPT 式章节停靠（Scroll Dock）
 *
 * 把长页面变成「一屏一屏翻」的演示稿手感：
 *   1. 滚轮 / PageDown / 空格 / 方向键 = 翻到相邻停靠点；
 *   2. 拖滚动条、触屏、锚点跳转等自由滚动，松手后强制对齐最近停靠点；
 *   3. 停靠点 = 四个主章节 + 长章节内部按视口高度补的过渡点，
 *      保证矩阵 / 动画 / 日志等中部内容仍一屏一屏看得到，不会被跳过；
 *   4. 右侧页码与圆点导航、当前章节标题行的细线高亮。
 *
 * 不改写页面结构、不请求服务端、不碰算法与动画。
 * 关闭：?snap=0 / ?wheel=0 / ?key=0 / 点导航底部「吸附 关」/ 按 Esc
 * 删掉 index.html 中本 <script>，则自动回退到 styles/base.css 里
 * 声明的原生 proximity 轻吸（本文件加载时会把 scroll-snap-type 覆盖为 none，
 * 避免两套吸附机制互相打架）。
 * ============================================================ */
(function () {
  'use strict';

  /* 四个主停靠点，与 styles/base.css 的 scroll-snap-align 声明一致 */
  var IDS = ['card-kmp', 'card-lcs', 'card-edit', 'sourceSection'];
  var LABELS = ['KMP 字符串匹配', '最长公共子序列', '编辑距离', '本页算法源码'];
  function T(s) { return (window.I18N && window.I18N.t) ? window.I18N.t(s) : s; }
  function L(i) { return T(LABELS[i]); }
  var OFFSET = 14;   /* 与 styles/base.css 的 scroll-margin-top 一致 */

  function qs(name) {
    var m = new RegExp('[?&]' + name + '=([^&]*)').exec(window.location.search || '');
    return m ? decodeURIComponent(m[1]) : null;
  }
  function $(id) { return document.getElementById(id); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  var CFG = {
    enabled: qs('snap') !== '0',
    wheel: qs('wheel') !== '0',
    keyboard: qs('key') !== '0',
    stepRatio: Math.min(1.1, Math.max(0.5, Number(qs('step')) || 0.86)),
    settleMs: 140,      /* 滚动停止判定 */
    lockMs: 560,        /* 翻页手势锁 + 平滑动画兜底时长 */
    tolerance: 4,       /* 校正容差，小于此值不再动人 */
    snap: true,         /* 停止后强制对齐 */
    topThreshold: qs('top') !== null ? Math.max(0, Number(qs('top')) || 0) : 180
                        /* 滚过这么多 px 才算「脱离顶部」，右下角箭头才出现；可用 ?top=120 调 */
  };

  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduced) { CFG.wheel = false; CFG.lockMs = 40; }

  var docks = [];      /* [{ top, section, main }] 全部停靠点，升序 */
  var mains = [];      /* 可见的主锚点 [{ top, section }] */
  var timer = 0, buildTimer = 0, animTimer = 0;
  var animating = false;
  var lockUntil = 0;
  var enabled = CFG.enabled;

  /* ---------- 位置工具 ---------- */
  function maxScroll() {
    return Math.max(0, (document.documentElement.scrollHeight || 0) - window.innerHeight);
  }
  function pageY(el) {
    return el.getBoundingClientRect().top +
      (window.pageYOffset || document.documentElement.scrollTop || 0);
  }
  function clampY(v) { return Math.max(0, Math.min(maxScroll(), Math.round(v))); }
  function nearestDock(y) {
    var best = 0, dist = Infinity;
    for (var i = 0; i < docks.length; i++) {
      var d = Math.abs(docks[i].top - y);
      if (d < dist) { dist = d; best = i; }
    }
    return best;
  }
  function clampDock(i) { return Math.max(0, Math.min(docks.length - 1, i)); }
  function sectionAt(y) {
    var s = -1;
    for (var i = 0; i < mains.length; i++) if (y + 2 >= mains[i].top) s = mains[i].section;
    return s;
  }

  /* ---------- 构建停靠点 ----------
   * 主锚点永远优先；相邻点间距超过「一屏」时均匀补过渡点。
   * 这是关键：mandatory 式强吸附之所以会「卡住长卡片」，是因为吸附点太少；
   * 补足之后每一屏都有落脚处，矩阵 / 动画 / 日志全都能翻到。 */
  function buildDocks() {
    var vh = window.innerHeight;
    var step = Math.max(220, Math.round(vh * CFG.stepRatio));
    var maxY = maxScroll();

    var anchors = IDS.map(function (id, i) {
      var n = $(id);
      if (!n || !n.getClientRects().length) return null;  /* hidden 的章节不参与 */
      return { top: clampY(pageY(n) - OFFSET), section: i, main: true };
    }).filter(Boolean);
    mains = anchors;

    var points = [{ top: 0, section: -1, main: true }];   /* 卷首 */
    anchors.forEach(function (a) { points.push(a); });
    if (maxY > 0) {
      points.push({ top: maxY, section: anchors.length ? anchors[anchors.length - 1].section : -1, main: false });
    }

    points.sort(function (a, b) { return a.top - b.top; });
    var uniq = [];
    points.forEach(function (p) {
      var last = uniq[uniq.length - 1];
      if (last && Math.abs(last.top - p.top) < 12) {
        if (p.main && !last.main) { last.top = p.top; last.section = p.section; last.main = true; }
      } else {
        uniq.push({ top: p.top, section: p.section, main: p.main });
      }
    });

    var out = [];
    for (var i = 0; i < uniq.length; i++) {
      var cur = uniq[i];
      out.push(cur);
      var next = uniq[i + 1];
      if (!next) continue;
      var gap = next.top - cur.top;
      if (gap <= step) continue;
      var n = Math.ceil(gap / step) - 1;
      for (var k = 1; k <= n; k++) {
        out.push({
          top: clampY(cur.top + gap * k / (n + 1)),
          section: cur.section,
          main: false
        });
      }
    }
    docks = out;
    renderNav();
    update();
  }

  /* ---------- 导航 UI ---------- */
  function renderNav() {
    var dots = $('dockDots');
    if (!dots) return;
    var visible = [];
    IDS.forEach(function (id, i) {
      var n = $(id);
      if (n && n.getClientRects().length) visible.push(i);
    });
    dots.innerHTML = visible.map(function (i) {
      return '<button type="button" class="dock-dot" data-section="' + i + '" title="' + T('跳到：') + L(i) + '">' +
        '<span class="dock-dot__n">' + pad(i + 1) + '</span>' +
        '<span class="dock-dot__label">' + L(i) + '</span></button>';
    }).join('');

    var list = dots.querySelectorAll('.dock-dot');
    for (var k = 0; k < list.length; k++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          if (!enabled) setEnabled(true);
          var sec = Number(btn.getAttribute('data-section'));
          var idx = 0;
          for (var j = 0; j < docks.length; j++) {
            if (docks[j].main && docks[j].section === sec) { idx = j; break; }
          }
          goTo(idx, true);
        });
      })(list[k]);
    }
  }

  function update() {
    var y = window.pageYOffset || 0;
    var idx = nearestDock(y);
    var s = sectionAt(y + 6);

    IDS.forEach(function (id, i) {
      var n = $(id);
      if (n) n.classList.toggle('is-anchored', i === s);
    });

    var p = $('dockPage');
    if (p) p.textContent = pad(idx + 1) + ' / ' + pad(docks.length);
    var label = $('dockLabel');
    if (label) label.textContent = s >= 0 ? L(s) : T('卷首 · 输入文本');

    var dots = $('dockDots');
    if (dots) {
      var list = dots.querySelectorAll('.dock-dot');
      for (var k = 0; k < list.length; k++) {
        list[k].classList.toggle('is-active', Number(list[k].getAttribute('data-section')) === s);
      }
    }
  }

  /* ---------- 回到顶部箭头 ----------
   * 只要滚离卷首就淡入；显隐只读写一个 class，不拦滚动、不改结构。
   * 阈值可用 ?top=120 调；隐藏时 CSS 的 visibility:hidden 让它不可聚焦。 */
  function updateToTop() {
    var btn = $('toTop');
    if (!btn) return;
    btn.classList.toggle('is-visible', (window.pageYOffset || 0) > CFG.topThreshold);
  }

  /* ---------- 滚动到某个停靠点 ---------- */
  function goTo(idx, lock) {
    if (!docks.length) return;
    idx = clampDock(idx);
    var top = docks[idx].top;
    animating = true;
    if (lock) lockUntil = Date.now() + CFG.lockMs;
    if (timer) { clearTimeout(timer); timer = 0; }
    clearTimeout(animTimer);
    try {
      window.scrollTo({ top: top, behavior: reduced ? 'instant' : 'smooth' });
    } catch (e) {
      window.scrollTo(0, top);   /* 老浏览器不支持 options */
    }
    /* 兜底：后台标签页 / 无头虚拟时间 / 低帧率下 smooth 可能不推进，
       到时若仍未到位就 instant 补齐，再判定一次对齐状态。 */
    animTimer = setTimeout(function () {
      animating = false;
      if (Math.abs((window.pageYOffset || 0) - top) > 4) {
        try { window.scrollTo({ top: top, behavior: 'instant' }); }
        catch (e2) { window.scrollTo(0, top); }
      }
      settle();
    }, reduced ? 30 : CFG.lockMs);
  }

  function settle() {
    update();
    if (!enabled || !CFG.snap || animating || !docks.length) return;
    var y = window.pageYOffset || 0;
    var idx = nearestDock(y);
    if (Math.abs(y - docks[idx].top) <= CFG.tolerance) return;
    goTo(idx, false);
  }

  function onScroll() {
    updateToTop();                 /* 箭头显隐跟着滚动实时走 */
    if (timer) clearTimeout(timer);
    timer = setTimeout(function () { timer = 0; settle(); }, CFG.settleMs);
  }

  /* ---------- 滚轮翻页 ---------- */
  function scrollableInside(node, dy) {
    var n = (node && node.nodeType === 1) ? node : null;
    while (n && n !== document.body && n !== document.documentElement) {
      if (n.nodeType === 1) {
        var oy = window.getComputedStyle(n).overflowY;
        if ((oy === 'auto' || oy === 'scroll') && n.scrollHeight > n.clientHeight + 2) {
          var atTop = n.scrollTop <= 1;
          var atBottom = n.scrollTop + n.clientHeight >= n.scrollHeight - 1;
          if ((dy < 0 && !atTop) || (dy > 0 && !atBottom)) return true;
        }
      }
      n = n.parentNode;
    }
    return false;
  }

  function onWheel(e) {
    if (!enabled || !CFG.wheel || reduced) return;
    if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;   /* 缩放 / 横向 */
    if (!e.deltaY || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
    if (scrollableInside(e.target, e.deltaY)) return;               /* 日志 / 源码 / 矩阵内部还能滚 */
    if (animating || Date.now() < lockUntil) {                      /* 吞掉惯性，避免一次手势连翻 */
      e.preventDefault();
      return;
    }
    e.preventDefault();
    var d = e.deltaY > 0 ? 1 : -1;
    goTo(nearestDock(window.pageYOffset || 0) + d, true);
  }

  /* ---------- 键盘翻页 ---------- */
  function onKey(e) {
    if (!enabled || !CFG.keyboard) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    var t = e.target;
    if (t && (/^(INPUT|TEXTAREA|SELECT|BUTTON|A)$/.test(t.tagName) || t.isContentEditable)) return;

    if (e.key === 'Escape') { setEnabled(false); return; }
    if (e.key === 'Home') { e.preventDefault(); goTo(0, true); return; }
    if (e.key === 'End') { e.preventDefault(); goTo(docks.length - 1, true); return; }

    var d = 0;
    if (e.key === 'PageDown' || e.key === 'ArrowDown' || e.key === ' ') d = 1;
    else if (e.key === 'PageUp' || e.key === 'ArrowUp') d = -1;
    else return;
    if (e.key === ' ' && e.shiftKey) d = -1;
    e.preventDefault();
    goTo(nearestDock(window.pageYOffset || 0) + d, true);
  }

  /* ---------- 开关 ---------- */
  function setEnabled(v) {
    enabled = !!v;
    document.body.classList.toggle('dock-off', !enabled);
    var btn = $('dockToggle');
    if (btn) {
      btn.textContent = enabled ? T('吸附 开') : T('吸附 关');
      btn.title = enabled ? T('点击关闭翻页吸附（恢复自由滚动）') : T('点击开启翻页吸附');
      btn.setAttribute('aria-pressed', String(!enabled));
    }
    if (!enabled) {
      clearTimeout(animTimer);
      animating = false;
      lockUntil = 0;
    } else {
      buildDocks();
    }
  }

  function debounceBuild() {
    if (buildTimer) clearTimeout(buildTimer);
    buildTimer = setTimeout(function () { buildTimer = 0; buildDocks(); }, 180);
  }

  /* ---------- 调试 / 验证接口 ---------- */
  window.ScrollDock = {
    rebuild: buildDocks,
    docks: function () {
      return docks.map(function (d) { return { top: d.top, section: d.section, main: d.main }; });
    },
    goTo: function (i) { goTo(i, true); },
    current: function () { return nearestDock(window.pageYOffset || 0); },
    section: function () { return sectionAt((window.pageYOffset || 0) + 6); },
    setEnabled: setEnabled,
    enabled: function () { return enabled; },
    settle: settle,
    topVisible: function () {
      var b = $('toTop');
      return !!b && b.classList.contains('is-visible');
    },
    config: CFG
  };

  function init() {
    /* JS 接管后关闭原生 snap，避免两套机制互相纠正；
       base.css 里的 proximity 保留为「删掉本脚本」时的轻吸兜底。 */
    document.documentElement.style.scrollSnapType = 'none';

    buildDocks();
    document.body.classList.add('dock-ready');
    setEnabled(CFG.enabled);

    /* 语言切换：按新语言重建圆点导航、章节标签与开关文字 */
    document.addEventListener('sim:langchange', function () {
      renderNav();
      setEnabled(enabled);
      update();
    });

    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('keydown', onKey);
    window.addEventListener('resize', debounceBuild);
    window.addEventListener('load', debounceBuild);

    if (window.MutationObserver) {
      [$('algorithms'), $('overview')].forEach(function (n) {
        if (n) new MutationObserver(debounceBuild).observe(n, {
          attributes: true, attributeFilter: ['hidden']
        });
      });
    }
    /* 检测完成后卡片高度会变（矩阵、日志撑开），重建停靠点 */
    if (window.ResizeObserver) {
      new ResizeObserver(debounceBuild).observe(document.querySelector('.sheet') || document.body);
    }
    var btn = $('dockToggle');
    if (btn) btn.addEventListener('click', function () { setEnabled(!enabled); });

    /* 回到顶部：复用 goTo(0)，与 PPT 停靠共用同一套平滑滚动与手势锁，
       不会被「松手校正」又拉回原页；即便关掉吸附（吸附 关 / ?snap=0）也能回卷首。 */
    var top = $('toTop');
    if (top) top.addEventListener('click', function () { goTo(0, true); });
    updateToTop();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
