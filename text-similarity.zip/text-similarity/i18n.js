/* ============================================================
 * i18n.js
 * 中英双语切换层 —— 中文原文即键，英文字典给出译文。
 *
 *   · 静态文案：index.html 里挂 data-i18n（纯文本）/ data-i18n-html
 *     （含 <strong> 等标签）/ data-i18n-ph（placeholder）
 *     / data-i18n-aria / data-i18n-title，apply() 逐个替换；
 *   · 动态文案：各控制器调用 I18N.t(模板, 参数…)（{0}{1} 占位），
 *     算法产出的中文数据串（结论 / 错误信息）走 I18N.tr()；
 *   · 切换：报头「EN / 中文」按钮，或 URL ?lang=en / ?lang=zh，
 *     偏好存 localStorage('simalgo.lang')，默认跟随浏览器语言；
 *   · 切换后广播 'sim:langchange'，app.js / analogy.js /
 *     scroll-anchor.js 各自重建受影响的动态内容。
 *
 * 说明：§ 03 展示的算法源码与其执行日志保持中文原样——
 * 它们是「本页真实运行代码」的一部分，不做翻译。
 * ============================================================ */
(function () {
  'use strict';

  /* zh 模式下绝大多数键即原文；仅这些「含 HTML / 特殊排版」的键需要给出 zh 版本 */
  var ZH_SPECIAL = {
    'hero.title': '文本相似度<span class="hero__accent">检测</span>',
    'hero.lede':
      '用三种经典算法同时审视两段文字：<strong>KMP</strong> 通过前缀表搜索公共片段，' +
      '<strong>LCS</strong> 用动态规划找回最长公共子序列，<strong>编辑距离</strong> 计算改写所需的最少操作。' +
      '点击一次「运行检测」，三种算法会在这个页面里各自填表、回溯，并同步播放三段看得懂的动画：' +
      '<strong>荧光笔划出相同整块、两支笔隔着空儿连线、红笔逐处批改计数</strong>——全部由浏览器本地完成，不请求任何服务端。',
    'demo.kmp.hint':
      '只划<strong>连着、一字不差</strong>的整块；散落各处的相同单字不算。这就是 KMP 搜索公共片段的方式。',
    'demo.lcs.hint':
      '从开头往后把相同的字连起来，<strong>中间可以跳过</strong>对不上的字，但线不能交叉——因为顺序不能乱。',
    'demo.edit.hint':
      '拿红笔把 A 改成 B：<strong>改一个字、加一个字、删一个字各算 1 笔</strong>，数最少要落几笔。',
    'sec.src.desc':
      '下方代码来自本页 &lt;script&gt; 实际加载并执行的文件；若以 file:// 直接打开无法读取文件，则自动降级为「正在执行的函数的 toString()」——两者都是真实运行的代码。<br>' +
      '每份源码开头都有「用大白话说」的导览；<strong>陶土色加粗的【块 N】标题</strong>把代码切成一块块，跟着写清这个块在干什么、输入什么、交出什么；「// ·」开头的灰色行是段内说明。顺着块标题往下读就能读懂每一块，注释不参与运行。'
  };

  /* 英文字典：键 = 中文原文（可含 {0} 占位符） */
  var EN = {
    /* ---- 标题与首屏 ---- */
    '文本相似度检测 · KMP / LCS / 编辑距离': 'Text Similarity Detection · KMP / LCS / Edit Distance',
    '文本相似度检测：在同一页面实时运行并可视化 KMP、LCS（最长公共子序列）与编辑距离三种算法。':
      'Text similarity detection: runs and visualizes KMP, LCS (longest common subsequence) and edit distance live on one page.',
    'Computational Linguistics / 文本计算': 'Computational Linguistics / Text Computation',
    'hero.title': 'Text Similarity<span class="hero__accent"> Detection</span>',
    'hero.lede':
      'Three classic algorithms examine two texts at once: <strong>KMP</strong> searches for common blocks via the prefix table, ' +
      '<strong>LCS</strong> recovers the longest common subsequence with dynamic programming, and <strong>Edit Distance</strong> counts the fewest operations needed to rewrite one text into the other. ' +
      'Click "Run detection" once and all three algorithms fill their tables and backtrack right on this page, each playing an easy-to-follow animation: ' +
      '<strong>a highlighter marking identical whole runs, two pens linking matching characters across gaps, a red pen marking and counting every edit</strong> — all computed locally in your browser, with zero server calls.',

    /* ---- § 01 输入 ---- */
    '输入文本': 'Input Texts',
    'Input / 两段待比较文本': 'Input / Two texts to compare',
    '文本 A · 基准': 'Text A · Reference',
    '文本 B · 对照': 'Text B · Compare',
    '0 字符': '0 chars',
    '{0} 字符': '{0} chars',
    '在此粘贴或输入第一段文本…': 'Paste or type the first text here…',
    '在此粘贴或输入第二段文本…': 'Paste or type the second text here…',
    '忽略大小写': 'Ignore case',
    '忽略空白': 'Ignore spaces',
    '忽略标点': 'Ignore punctuation',
    '轨迹动画': 'Trace animation',
    '自动循环': 'Auto replay',
    '自动循环 · 待命': 'Auto replay · standby',
    '速度': 'Speed',
    '慢速': 'Slow',
    '标准': 'Normal',
    '即时': 'Instant',
    '运行文本相似度检测 →': 'Run similarity detection →',
    '运行中…': 'Running…',
    '清空': 'Clear',
    '载入示例': 'Load sample',
    '近似中文': 'Near-duplicate (zh)',
    '完全相同': 'Identical',
    '差异较大': 'Very different',
    '英文近似': 'Near-duplicate (en)',

    /* ---- 总览 ---- */
    '/ 100 · 加权综合': '/ 100 · weighted composite',
    '等待检测': 'Awaiting detection',
    'KMP 覆盖率': 'KMP coverage',
    'LCS 比率': 'LCS ratio',
    '编辑距离': 'Edit distance',
    '综合分 = 0.25 × KMP + 0.40 × LCS + 0.35 × 编辑距离':
      'Composite = 0.25 × KMP + 0.40 × LCS + 0.35 × Edit distance',
    '综合分 = {0} × KMP + {1} × LCS + {2} × 编辑距离　|　归一化后 |A|={3}，|B|={4}':
      'Composite = {0} × KMP + {1} × LCS + {2} × Edit distance | after normalization |A|={3}, |B|={4}',
    '就绪': 'Ready',
    '等待输入…': 'Awaiting input…',
    '计算完毕 · 轨迹回放中': 'Computed · replaying traces',
    '计算耗时 {0} ms<br>轨迹回放中…': 'Compute time {0} ms<br>replaying traces…',
    '检测完成 · 3/3 已执行': 'Detection complete · 3/3 executed',
    'KMP  {0} ms<br>LCS  {1} ms<br>EDIT {2} ms<br>合计 {3} ms':
      'KMP  {0} ms<br>LCS  {1} ms<br>EDIT {2} ms<br>total {3} ms',

    /* ---- § 02 算法卡片 ---- */
    '算法执行轨迹': 'Algorithm Execution Trace',
    'Live Trace / 同页并行运行': 'Live Trace / parallel on this page',
    'KMP 字符串匹配': 'KMP String Matching',
    '最长公共子序列': 'Longest Common Subsequence',
    '直观演示': 'Visual demo',
    '荧光笔 · 划出「一模一样的整句话」': 'Highlighter · marks identical whole runs',
    '两支笔 · 隔着空儿划连线': 'Two pens · links matching chars across gaps',
    '红笔批改 · 数最少改几处': 'Red pen · counts the fewest edits',
    '等待检测…': 'Waiting for detection…',
    'demo.kmp.hint':
      'Only marks <strong>contiguous, character-exact</strong> whole runs; scattered identical single characters do not count. This is exactly how KMP searches for common blocks.',
    'demo.lcs.hint':
      'Links identical characters from left to right; <strong>skipping</strong> non-matching characters in between is allowed, but lines must never cross — order cannot change.',
    'demo.edit.hint':
      'Rewrite A into B with the red pen: <strong>a substitution, an insertion and a deletion each cost 1 stroke</strong> — count the fewest strokes needed.',
    'A · next 前缀表': 'A · next prefix table',
    'B · 匹配指针轨迹': 'B · live match trace',
    'C · KMP 搜索到的公共片段': 'C · common blocks found by KMP',
    'A · DP 矩阵与回溯路径': 'A · DP matrix & backtrack path',
    'B · 回溯得到的 LCS': 'B · LCS recovered by backtracking',
    'A · 代价矩阵与回溯路径': 'A · cost matrix & backtrack path',
    'B · 最小编辑操作': 'B · minimal edit operations',
    '当前比较': 'comparing',
    'next 回退': 'next fallback',
    '命中': 'hit',
    '数值热度': 'value heat',
    '字符相等': 'chars equal',
    '回溯路径': 'backtrack path',
    '代价热度': 'cost heat',
    '保留': 'keep',
    '替换': 'sub',
    '插入': 'insert',
    '删除': 'delete',
    '执行日志 · ': 'Execution log · ',
    ' 条 · ': ' entries · ',

    /* ---- 卡片内动态 ---- */
    '准备匹配…': 'Preparing…',
    '未找到长度 ≥ {0} 的公共片段。': 'No common block of length ≥ {0} found.',
    '两段文本没有公共字符。': 'The two texts share no characters.',
    '无需任何编辑操作': 'No edit operations needed',
    '模式串 P = <b>{0}</b>　·　next = [{1}]<br>文本 T（演示窗口取前 48 字符）= {2}':
      'Pattern P = <b>{0}</b> · next = [{1}]<br>Text T (demo window, first 48 chars) = {2}',
    '文本 T': 'Text T',
    '模式 P': 'Pattern P',
    '动作': 'Action',
    '比较 T[{0}]={1} 与 P[{2}]={3} → 相等，i/j 同时前进':
      'Compare T[{0}]={1} with P[{2}]={3} → equal; i and j advance together',
    '失配 → 查 next 回退 j: {0} → {1}，i 不动':
      'Mismatch → follow next to fall back j: {0} → {1}; i stays put',
    '命中！模式串在 T[{0}] 处完整匹配': 'Hit! Pattern fully matches at T[{0}]',
    'j=0 且失配 → i 前进到 {0}': 'j=0 and mismatch → advance i to {0}',
    '运行结束：{0} 次比较，{1} 次回退，命中 {2} 处':
      'Done: {0} comparisons, {1} fallbacks, {2} hits',
    '最长公共子串': 'Longest common substring',
    '公共片段数': 'Common blocks',
    '命中 / 分母': 'Matched / denom',
    'next 回退次数': 'next fallbacks',
    '字符比较总数': 'Total char comparisons',
    '二分验证轮次': 'Binary-search rounds',
    'LCS 长度': 'LCS length',
    'DP 单元格': 'DP cells',
    '相等字符格': 'Equal-char cells',
    '回溯步数': 'Backtrack steps',
    '相似度 = 2 × {0} / ({1} + {2}) = {3} 分。':
      'Similarity = 2 × {0} / ({1} + {2}) = {3} pts.',
    '相似度 = (1 − {0} / {1}) × 100 = {2} 分。':
      'Similarity = (1 − {0} / {1}) × 100 = {2} pts.',
    '矩阵过大，可视化仅展示前 {0} 行 × {1} 列；评分与回溯仍基于完整矩阵计算。':
      'Matrix too large; the visualization shows only the first {0} rows × {1} cols. Scoring and backtracking still use the full matrix.',
    '算法返回结果不完整。': 'The algorithms returned incomplete results.',
    '配置或算法模块未加载：请确认 config/app.config.js 与 algorithms/*.js 均已按 index.html 顺序引入。':
      'Config or algorithm modules not loaded: make sure config/app.config.js and algorithms/*.js are included in the order used by index.html.',

    /* ---- 直观演示（analogy.js）---- */
    'A 原文': 'A source',
    'B 结果': 'B target',
    '红笔已落下 <b id="editRedCount">0</b> 笔':
      'Red pen strokes: <b id="editRedCount">0</b>',
    '（等待批改…）': ' (awaiting markup…)',
    '（文本较长，演示区只显示第 {0}–{1} 个字符；评分仍按全文计算）':
      ' (long text: the demo window shows chars {0}–{1} only; scoring still uses the full text)',
    '没有找到一模一样的整块（0 处）': 'No identical whole run found (0)',
    '第 {0} 块｜正在划「{1}」': 'Block {0} | marking "{1}"',
    '完成｜划出 {0} 块，演示区标记 {1} 个字':
      'Done | marked {0} blocks, {1} chars in the demo window',
    '（算法要求 ≥{0} 字成块，此处仅展示最长公共子串）':
      ' (the algorithm requires ≥{0} chars per block; showing the longest common substring instead)',
    '一个字都对不上（0 根线）': 'No character pairs at all (0 lines)',
    '第 {0} / {1} 根线｜已连上 {0} 个字': 'Line {0}/{1} | {0} chars linked',
    '完成｜共 {0} 根线，互不交叉（顺序一致）':
      'Done | {0} lines in total, none crossing (order preserved)',
    '两篇完全一样，一笔都不用改': 'The two texts are identical — no edits needed',
    ' · 编辑距离 = 0': ' · edit distance = 0',
    ' · 当前：{0}': ' · now: {0}',
    '红笔第 {0} 步 / 共 {1} 步': 'Red pen step {0} / {1}',
    ' · 这就是最少改动次数': ' · this is the fewest edits possible',
    '批改完成｜最少只需 {0} 笔': 'Markup complete | only {0} strokes needed',
    '自动循环 · 已停止': 'Auto replay · stopped',
    '自动循环 · 第 {0} 遍': 'Auto replay · round {0}',
    '自动循环 · 待命重播': 'Auto replay · queued',

    /* ---- 源码面板 ---- */
    '本页实际运行的算法源码': 'Source code actually running on this page',
    'Source / 非示例，非伪代码': 'Source / real code, not pseudocode',
    'sec.src.desc':
      'The code below comes from the files this page actually loads and executes; when opened via file:// file reads are blocked, so it falls back to the toString() of the functions currently executing — both are the real running code.<br>' +
      'Each file opens with a plain-language tour; <strong>the bold terracotta 【块 N】 headings</strong> cut the code into blocks that say what each one does, takes in and hands back; grey lines starting with "// ·" are inline notes. Follow the block headings top to bottom and every block becomes readable. Comments and execution logs stay in Chinese — they are part of the authentic source output.',
    '选择上方标签以查看源码…': 'Pick a tab above to view the source…',
    '正在读取 {0} …': 'Loading {0} …',
    '03 / 编辑距离': '03 / Edit distance',
    '04 / 编排层': '04 / Orchestrator',
    '// 用 file:// 直接打开时浏览器不允许 fetch 源文件，于是改成：\n// 从正在运行的代码里把函数原样取出来（Function.prototype.toString()），\n// 与页面上真正执行的完全一致，注释也不是另写的。':
      '// When opened via file:// the browser forbids fetching the source files, so instead:\n// the functions currently running are taken verbatim from memory (Function.prototype.toString()),\n// identical to what actually executes on this page — the comments are not rewritten either.',
    '// 荧光笔那一支：做退路表 → 逐字比对 → 二分猜整块长度 → 把公共块划出来':
      '// The highlighter pen: build the fallback table → compare char by char → binary-guess block length → mark the common blocks',
    '// 块地图：① 外壳 ② 计时 ③ 退路表 ④ 逐字比对 ⑤ 二分猜长度 ⑥ 荧光笔分块 ⑦ 总入口 ⑧ 出口':
      '// Block map: 1 shell · 2 timing · 3 fallback table · 4 char compare · 5 binary guess · 6 block marking · 7 entry · 8 exit',
    '// 两支笔连线那一支：铺 DP 成绩表 → 从右下角倒着走回去捡公共字':
      '// The two linking pens: fill the DP score table → walk back from the bottom-right corner collecting common chars',
    '// 块地图：① 外壳 ② 计时 ③ 铺表 / 填表 / 回溯（内含逐段说明） ④ 出口':
      '// Block map: 1 shell · 2 timing · 3 table / fill / backtrack (with inline notes) · 4 exit',
    '// 红笔批改那一支：铺代价表 → 回溯出「保留 / 替换 / 插入 / 删除」清单':
      '// The red markup pen: fill the cost table → backtrack into a "keep / sub / insert / delete" list',
    '// 块地图：① 外壳 ② 计时 ③ 代价表 / 批改清单（内含逐段说明） ④ 出口':
      '// Block map: 1 shell · 2 timing · 3 cost table / markup list (with inline notes) · 4 exit',
    '// 主持人：收拾文本 → 请三位检查员各算各的分 → 加权给结论':
      '// The host: tidy the texts → let the three inspectors each score their way → weight the verdict',
    '// 块地图：① 外壳与依赖 ② 收拾文本 ③ 三位检查员打分 ④ 出口':
      '// Block map: 1 shell & deps · 2 tidy texts · 3 three inspectors score · 4 exit',
    '── 函数 {0} ──': '── function {0} ──',

    /* ---- 算法简介（config/app.config.js，经 I18N.tr 显示）---- */
    '用 next 前缀表跳过无效回溯，把公共片段搜索变成线性匹配；以「公共片段覆盖率」衡量相似。':
      'The next prefix table skips useless backtracking, turning common-block search into linear matching; similarity is measured by "common block coverage".',
    '动态规划填表并回溯，找出两段文本保持顺序的最长公共字符序列。':
      'Dynamic programming fills the table and backtracks to find the longest common character sequence that keeps order in both texts.',
    '动态规划求把文本 A 改成文本 B 所需的最少插入、删除、替换次数。':
      'Dynamic programming finds the minimum number of insertions, deletions and substitutions needed to turn text A into text B.',

    /* ---- 停靠导航 / 回顶（scroll-anchor.js）---- */
    '本页算法源码': 'Source code (this page)',
    '卷首 · 输入文本': 'Cover · Input Texts',
    '跳到：': 'Jump to: ',
    '吸附 开': 'Snap: on',
    '吸附 关': 'Snap: off',
    '点击关闭翻页吸附（恢复自由滚动）': 'Click to disable paging snap (free scrolling)',
    '点击开启翻页吸附': 'Click to enable paging snap',
    '顶部': 'Top',
    '回到顶部': 'Back to top',
    '回到顶部 · 卷首': 'Back to top · page start',
    '章节翻页导航': 'Section paging navigation'
  };

  /* tr()：算法产出的中文数据串（结论 / 错误） → 英文 */
  var PHRASES = {
    '高度相似': 'Highly similar',
    '部分相似': 'Partially similar',
    '差异较大': 'Very different',
    '算法模块未加载：请确认 algorithms/ 下三个 js 文件按 index.html 中的顺序引入。':
      'Algorithm modules not loaded: make sure the three js files under algorithms/ are included in the order used by index.html.'
  };
  var RULES = [
    [/^归一化后单段文本不得超过 (\d+) 个字符（当前 A=(\d+)，B=(\d+)）。$/,
     'After normalization each text must be at most $1 chars (A=$2, B=$3).'],
    [/^DP 矩阵规模超过保护上限 (\d+) 格，请缩短文本。$/,
     'The DP matrix exceeds the guard limit of $1 cells; please shorten the texts.']
  ];

  var lang = 'zh';
  try {
    lang = localStorage.getItem('simalgo.lang') ||
      (/^en/i.test(navigator.language || '') ? 'en' : 'zh');
  } catch (e) { /* 隐私模式等拿不到 localStorage，用默认值 */ }
  var q = new RegExp('[?&]lang=(zh|en)').exec(window.location.search || '');
  if (q) lang = q[1];

  /* t(模板, 参数…)：zh 返回模板本身；en 查字典，缺译则回退中文模板 */
  function t(tpl) {
    var s = lang === 'en' ? (EN[tpl] || tpl) : (ZH_SPECIAL[tpl] || tpl);
    for (var i = 1; i < arguments.length; i++) {
      s = s.split('{' + (i - 1) + '}').join(String(arguments[i]));
    }
    return s;
  }

  /* tr(数据串)：翻译算法产出的中文结论 / 错误信息；查不到原样返回 */
  function tr(s) {
    if (lang !== 'en' || s == null) return s;
    s = String(s);
    if (EN[s]) return EN[s];
    if (PHRASES[s]) return PHRASES[s];
    for (var i = 0; i < RULES.length; i++) {
      var m = RULES[i][0].exec(s);
      if (m) {
        var out = RULES[i][1];
        for (var k = 1; k < m.length; k++) out = out.split('$' + k).join(m[k]);
        return out;
      }
    }
    return s;
  }

  function apply(l) {
    lang = l === 'en' ? 'en' : 'zh';
    try { localStorage.setItem('simalgo.lang', lang); } catch (e) {}

    document.documentElement.setAttribute('lang', lang === 'en' ? 'en' : 'zh-CN');
    document.title = t('文本相似度检测 · KMP / LCS / 编辑距离');
    var md = document.querySelector('meta[name="description"]');
    if (md) md.setAttribute('content',
      t('文本相似度检测：在同一页面实时运行并可视化 KMP、LCS（最长公共子序列）与编辑距离三种算法。'));

    var nodes = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < nodes.length; i++) nodes[i].textContent = t(nodes[i].getAttribute('data-i18n'));
    nodes = document.querySelectorAll('[data-i18n-html]');
    for (i = 0; i < nodes.length; i++) nodes[i].innerHTML = t(nodes[i].getAttribute('data-i18n-html'));
    nodes = document.querySelectorAll('[data-i18n-ph]');
    for (i = 0; i < nodes.length; i++) nodes[i].setAttribute('placeholder', t(nodes[i].getAttribute('data-i18n-ph')));
    nodes = document.querySelectorAll('[data-i18n-aria]');
    for (i = 0; i < nodes.length; i++) nodes[i].setAttribute('aria-label', t(nodes[i].getAttribute('data-i18n-aria')));
    nodes = document.querySelectorAll('[data-i18n-title]');
    for (i = 0; i < nodes.length; i++) nodes[i].setAttribute('title', t(nodes[i].getAttribute('data-i18n-title')));

    var btn = document.getElementById('langToggle');
    if (btn) btn.textContent = lang === 'zh' ? 'EN' : '中文';

    /* 让 app.js / analogy.js / scroll-anchor.js 重建各自的动态内容 */
    document.dispatchEvent(new CustomEvent('sim:langchange'));
  }

  function toggle() { apply(lang === 'zh' ? 'en' : 'zh'); }
  function current() { return lang; }

  function bindToggle() {
    var btn = document.getElementById('langToggle');
    if (btn && !btn.dataset.i18nBound) {
      btn.dataset.i18nBound = '1';
      btn.addEventListener('click', toggle);
    }
  }

  window.I18N = { t: t, tr: tr, apply: apply, toggle: toggle, current: current };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      bindToggle();
      apply(lang);
    });
  } else {
    bindToggle();
    apply(lang);
  }
})();
