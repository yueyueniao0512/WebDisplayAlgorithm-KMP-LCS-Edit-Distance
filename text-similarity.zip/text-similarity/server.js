/* ============================================================
 * server.js
 * 零依赖静态服务器。端口/根目录等来自 config/app.config.json。
 * 用法： node server.js [端口]
 * ============================================================ */
'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = __dirname;
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config', 'app.config.json'), 'utf8'));
const serverCfg = cfg.server || {};
const PORT = Number(process.argv[2] || process.env.PORT || serverCfg.port || 4173);
const HOST = process.env.HOST || serverCfg.host || '127.0.0.1';
const DEFAULT_FILE = serverCfg.defaultFile || 'index.html';
const CACHE = serverCfg.cacheControl || 'no-cache';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.map': 'application/json; charset=utf-8'
};

const server = http.createServer((req, res) => {
  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  } catch (_) {
    res.writeHead(400).end('Bad request');
    return;
  }
  if (pathname === '/' || pathname.endsWith('/')) pathname += DEFAULT_FILE;

  const filePath = path.resolve(ROOT, '.' + pathname);
  if (!filePath.startsWith(ROOT + path.sep) && filePath !== ROOT) {
    res.writeHead(403).end('Forbidden');
    return;
  }

  fs.readFile(filePath, (err, buf) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('404 · 未找到 ' + pathname);
      return;
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': CACHE,
      'X-Content-Type-Options': 'nosniff'
    });
    res.end(buf);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`[${cfg.project.name}] ${cfg.project.title}`);
  console.log(`  本地地址 : http://${HOST}:${PORT}/`);
  console.log(`  项目根   : ${ROOT}`);
  console.log(`  配置文件 : config/app.config.json`);
  console.log('  Ctrl+C 停止');
});
